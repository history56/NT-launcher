package com.ntc.launcher.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootCompletedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED || intent?.action == "android.intent.action.QUICKBOOT_POWERON") {
            // Restore exact midnight alarm after phone reboot
            MidnightAlarmReceiver.scheduleNextMidnightAlarm(context)
        }
    }
}
