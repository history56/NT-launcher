package com.ntc.launcher.data.local.dao

import androidx.room.*
import com.ntc.launcher.data.local.entity.DailySessionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface DailySessionDao {
    @Query("SELECT * FROM daily_sessions ORDER BY date DESC")
    fun getAllSessions(): Flow<List<DailySessionEntity>>

    @Query("SELECT * FROM daily_sessions WHERE date = :date LIMIT 1")
    suspend fun getSessionByDate(date: String): DailySessionEntity?

    @Query("SELECT * FROM daily_sessions WHERE date BETWEEN :startDate AND :endDate ORDER BY date ASC")
    suspend fun getSessionsBetweenDates(startDate: String, endDate: String): List<DailySessionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateSession(session: DailySessionEntity)

    @Query("DELETE FROM daily_sessions")
    suspend fun clearAllSessions()
}
