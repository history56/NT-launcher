package com.ntc.launcher.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.ntc.launcher.data.local.dao.DailySessionDao
import com.ntc.launcher.data.local.dao.GoalDao
import com.ntc.launcher.data.local.entity.DailyGoalEntity
import com.ntc.launcher.data.local.entity.DailySessionEntity

@Database(
    entities = [DailyGoalEntity::class, DailySessionEntity::class],
    version = 1,
    exportSchema = false
)
abstract class NtcDatabase : RoomDatabase() {
    abstract fun goalDao(): GoalDao
    abstract fun dailySessionDao(): DailySessionDao

    companion object {
        @Volatile
        private var INSTANCE: NtcDatabase? = null

        fun getDatabase(context: Context): NtcDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    NtcDatabase::class.java,
                    "ntc_launcher_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
