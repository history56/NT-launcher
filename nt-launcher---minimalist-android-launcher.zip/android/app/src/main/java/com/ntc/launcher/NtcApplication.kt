package com.ntc.launcher

import android.app.Application
import com.ntc.launcher.data.repository.GoalRepository
import com.ntc.launcher.receiver.MidnightAlarmReceiver
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class NtcApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Ensure database initialized and midnight alarm scheduled
        MidnightAlarmReceiver.scheduleNextMidnightAlarm(this)
        CoroutineScope(Dispatchers.IO).launch {
            GoalRepository.getInstance(this@NtcApplication).ensureTodaySessionInitialized()
        }
    }
}
