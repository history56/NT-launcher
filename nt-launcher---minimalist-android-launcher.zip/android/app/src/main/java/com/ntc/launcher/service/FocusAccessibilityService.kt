package com.ntc.launcher.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class FocusAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val packageName = event.packageName?.toString() ?: return
            
            // Check if Focus session is currently active and packageName is in blocked list
            val sharedPrefs = getSharedPreferences("ntc_focus_prefs", MODE_PRIVATE)
            val isFocusActive = sharedPrefs.getBoolean("is_focus_active", false)
            val blockedList = sharedPrefs.getStringSet("blocked_apps", emptySet()) ?: emptySet()
            val emergencyExpiresAt = sharedPrefs.getLong("emergency_expires_at", 0L)

            // If emergency 60s window is active, do not block
            val isEmergencyActive = System.currentTimeMillis() < emergencyExpiresAt

            if (isFocusActive && !isEmergencyActive && blockedList.contains(packageName)) {
                // Return to home launcher
                val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_HOME)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                startActivity(homeIntent)
            }
        }
    }

    override fun onInterrupt() {
        // Handle interruption gracefully
    }
}
