package com.ntc.launcher.security

import android.content.Context
import android.util.Base64
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Handles Goal Completion Password/PIN.
 * Stored securely using Android Keystore & EncryptedSharedPreferences.
 * Never logs or exposes password in plain text.
 */
class SecurityManager(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val securePrefs = EncryptedSharedPreferences.create(
        context,
        "ntc_secure_credentials",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    companion object {
        private const val KEY_SALT = "pin_salt"
        private const val KEY_HASH = "pin_hash"
        private const val KEY_CONFIGURED = "is_pin_configured"
        private const val ITERATIONS = 10000
        private const val KEY_LENGTH = 256
    }

    fun isPinConfigured(): Boolean {
        return securePrefs.getBoolean(KEY_CONFIGURED, false)
    }

    fun setupPin(pin: String): Boolean {
        val random = SecureRandom()
        val salt = ByteArray(16)
        random.nextBytes(salt)
        val saltString = Base64.encodeToString(salt, Base64.NO_WRAP)

        val hashString = hashPinWithSalt(pin, salt)
        securePrefs.edit()
            .putString(KEY_SALT, saltString)
            .putString(KEY_HASH, hashString)
            .putBoolean(KEY_CONFIGURED, true)
            .apply()
        return true
    }

    fun verifyPin(inputPin: String): Boolean {
        if (!isPinConfigured()) return false
        val saltString = securePrefs.getString(KEY_SALT, null) ?: return false
        val storedHash = securePrefs.getString(KEY_HASH, null) ?: return false

        val salt = Base64.decode(saltString, Base64.NO_WRAP)
        val computedHash = hashPinWithSalt(inputPin, salt)
        return computedHash == storedHash
    }

    fun resetPin(): Boolean {
        // Explicit reset of credentials without touching Room database history
        securePrefs.edit()
            .remove(KEY_SALT)
            .remove(KEY_HASH)
            .putBoolean(KEY_CONFIGURED, false)
            .apply()
        return true
    }

    private fun hashPinWithSalt(pin: String, salt: ByteArray): String {
        val spec = PBEKeySpec(pin.toCharArray(), salt, ITERATIONS, KEY_LENGTH)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val hash = factory.generateSecret(spec).encoded
        return Base64.encodeToString(hash, Base64.NO_WRAP)
    }
}
