package com.ntc.launcher.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "daily_sessions")
data class DailySessionEntity(
    @PrimaryKey
    val date: String, // YYYY-MM-DD
    val isClosed: Boolean,
    val doingCount: Int,
    val excuseCount: Int,
    val pendingCount: Int,
    val doingPercent: Int,    // doingCount / 6 * 100
    val excusePercent: Int,   // excuseCount / 6 * 100
    val pendingPercent: Int,  // pendingCount / 6 * 100
    val createdAt: Long,
    val closedAt: Long? = null
)
