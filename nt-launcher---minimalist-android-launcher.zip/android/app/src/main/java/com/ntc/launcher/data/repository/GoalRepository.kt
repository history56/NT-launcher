package com.ntc.launcher.data.repository

import android.content.Context
import com.ntc.launcher.data.local.NtcDatabase
import com.ntc.launcher.data.local.entity.DailyGoalEntity
import com.ntc.launcher.data.local.entity.DailySessionEntity
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class GoalRepository private constructor(context: Context) {

    private val db = NtcDatabase.getDatabase(context)
    private val goalDao = db.goalDao()
    private val sessionDao = db.dailySessionDao()
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

    fun getTodayDateString(): String = dateFormat.format(Date())

    fun observeTodayGoals(): Flow<List<DailyGoalEntity>> {
        val today = getTodayDateString()
        return goalDao.getGoalsForDate(today)
    }

    suspend fun ensureTodaySessionInitialized() {
        val today = getTodayDateString()
        val existingGoals = goalDao.getGoalsForDateSync(today)
        if (existingGoals.isEmpty()) {
            val freshGoals = (0 until 6).map { slot ->
                DailyGoalEntity(
                    id = "goal_${today}_$slot",
                    sessionDate = today,
                    slotIndex = slot,
                    title = "",
                    status = "pending",
                    completedAt = null
                )
            }
            goalDao.insertGoals(freshGoals)
        }
    }

    suspend fun updateGoalTitle(goalId: String, newTitle: String) {
        goalDao.updateGoalTitle(goalId, newTitle)
    }

    suspend fun markGoalDoing(goalId: String) {
        goalDao.updateGoalStatus(goalId, "doing", System.currentTimeMillis())
    }

    suspend fun markGoalExcuse(goalId: String, reason: String?) {
        val goal = goalDao.getGoalsForDateSync(getTodayDateString()).find { it.id == goalId }
        if (goal != null) {
            goalDao.updateGoal(goal.copy(status = "excuse", excuseReason = reason))
        }
    }

    suspend fun reconcileSessionAtMidnight() {
        val yesterday = getYesterdayDateString()
        val goals = goalDao.getGoalsForDateSync(yesterday)
        if (goals.isNotEmpty()) {
            val doingCount = goals.count { it.status == "doing" }
            val excuseCount = goals.count { it.status == "excuse" }
            val pendingCount = goals.count { it.status == "pending" }

            val doingPercent = Math.round((doingCount.toFloat() / 6f) * 100)
            val excusePercent = Math.round((excuseCount.toFloat() / 6f) * 100)
            val pendingPercent = Math.round((pendingCount.toFloat() / 6f) * 100)

            val session = DailySessionEntity(
                date = yesterday,
                isClosed = true,
                doingCount = doingCount,
                excuseCount = excuseCount,
                pendingCount = pendingCount,
                doingPercent = doingPercent,
                excusePercent = excusePercent,
                pendingPercent = pendingPercent,
                createdAt = System.currentTimeMillis() - 86400000L,
                closedAt = System.currentTimeMillis()
            )
            sessionDao.insertOrUpdateSession(session)
        }
        ensureTodaySessionInitialized()
    }

    private fun getYesterdayDateString(): String {
        val cal = java.util.Calendar.getInstance()
        cal.add(java.util.Calendar.DAY_OF_YEAR, -1)
        return dateFormat.format(cal.time)
    }

    companion object {
        @Volatile
        private var INSTANCE: GoalRepository? = null

        fun getInstance(context: Context): GoalRepository {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: GoalRepository(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
