package com.ntc.launcher.data.local.dao

import androidx.room.*
import com.ntc.launcher.data.local.entity.DailyGoalEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface GoalDao {
    @Query("SELECT * FROM daily_goals WHERE sessionDate = :date ORDER BY slotIndex ASC")
    fun getGoalsForDate(date: String): Flow<List<DailyGoalEntity>>

    @Query("SELECT * FROM daily_goals WHERE sessionDate = :date ORDER BY slotIndex ASC")
    suspend fun getGoalsForDateSync(date: String): List<DailyGoalEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoals(goals: List<DailyGoalEntity>)

    @Update
    suspend fun updateGoal(goal: DailyGoalEntity)

    @Query("UPDATE daily_goals SET title = :newTitle WHERE id = :goalId")
    suspend fun updateGoalTitle(goalId: String, newTitle: String)

    @Query("UPDATE daily_goals SET status = :status, completedAt = :completedAt WHERE id = :goalId")
    suspend fun updateGoalStatus(goalId: String, status: String, completedAt: Long?)

    @Query("DELETE FROM daily_goals")
    suspend fun clearAllGoals()
}
