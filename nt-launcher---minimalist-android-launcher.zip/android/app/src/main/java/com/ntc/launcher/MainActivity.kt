package com.ntc.launcher

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ntc.launcher.data.repository.GoalRepository

class MainActivity : ComponentActivity() {

    private lateinit var goalRepository: GoalRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        goalRepository = GoalRepository.getInstance(this)

        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF0F111A)
                ) {
                    HomeScreen(
                        onLaunchPhone = { launchPhone() },
                        onLaunchCamera = { launchCamera() },
                        onLaunchKhanGS = { launchKhanGlobalStudies() }
                    )
                }
            }
        }
    }

    private fun launchPhone() {
        val intent = Intent(Intent.ACTION_DIAL)
        startActivity(intent)
    }

    private fun launchCamera() {
        val intent = Intent("android.media.action.STILL_IMAGE_CAMERA")
        if (intent.resolveActivity(packageManager) != null) {
            startActivity(intent)
        } else {
            Toast.makeText(this, "Camera app not found", Toast.LENGTH_SHORT).show()
        }
    }

    private fun launchKhanGlobalStudies() {
        val packageName = "xyz.penpencil.khanglobalstudies"
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            startActivity(launchIntent)
        } else {
            // Graceful fallback: Open Play Store or Web Portal rather than crashing
            Toast.makeText(this, "Khan Global Studies app not found. Opening study portal...", Toast.LENGTH_LONG).show()
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")))
            } catch (e: Exception) {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://khanglobalstudies.com")))
            }
        }
    }
}

@Composable
fun HomeScreen(
    onLaunchPhone: () -> Unit,
    onLaunchCamera: () -> Unit,
    onLaunchKhanGS: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("NTC Launcher", color = Color.White, fontSize = 18.sp)
        Text("Native Android 12 Home Launcher for Vivo V21", color = Color.Gray, fontSize = 12.sp)
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Button(onClick = onLaunchPhone) { Text("Phone") }
            Button(onClick = onLaunchCamera) { Text("Camera") }
            Button(onClick = onLaunchKhanGS) { Text("Khan GS") }
        }
    }
}
