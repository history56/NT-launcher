package com.ntc.launcher.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "daily_goals",
    indices = [Index(value = ["sessionDate", "slotIndex"], unique = true)]
)
data class DailyGoalEntity(
    @PrimaryKey
    val id: String,
    val sessionDate: String, // YYYY-MM-DD
    val slotIndex: Int,      // strictly 0 to 5 (exactly 6 goals)
    val title: String,
    val status: String,     // "doing", "excuse", "pending"
    val completedAt: Long? = null,
    val excuseReason: String? = null,
    val notes: String? = null
)
