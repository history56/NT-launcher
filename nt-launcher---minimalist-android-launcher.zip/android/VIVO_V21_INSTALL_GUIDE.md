# NTC Launcher — Vivo V21 (Android 12 / Funtouch OS) Complete Setup Guide

## 1. How to Build the Debug APK in Android Studio
1. Launch **Android Studio** (Flamingo, Giraffe, Hedgehog, or newer).
2. Choose **File > Open** and select the `/android` directory.
3. Allow Gradle to synchronize dependencies (JDK 17 configured in Settings > Build, Execution, Deployment > Build Tools > Gradle).
4. Connect your **Vivo V21** via USB cable or use the emulator.
5. In the top toolbar, ensure the run target is set to `:app`.
6. Go to **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. Upon build completion, click **locate** or find the APK at:
   `app/build/outputs/apk/debug/app-debug.apk`

---

## 2. Installing the APK on Vivo V21 (Android 12)
1. Enable Developer Options:
   - Go to **Settings > About phone > Software information**.
   - Tap **Build number** 7 times until you see "You are now a developer!".
2. Enable USB Debugging:
   - Go to **Settings > System > Developer options**.
   - Enable **USB debugging**.
3. Install via ADB:
   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```
   *Alternatively, transfer `app-debug.apk` via Google Drive or USB file transfer and tap the APK to install.*

---

## 3. Selecting NTC Launcher as the Default Home App
1. Open **Settings** on your Vivo V21.
2. Tap **Applications and permissions** (or **Apps**).
3. Tap **Default app settings**.
4. Select **Home screen**.
5. Choose **NTC Launcher**.
6. Press the physical/gesture Home indicator to verify NTC Launcher loads immediately.

---

## 4. Funtouch OS Background Process Settings (Crucial for Vivo V21)
Vivo's Funtouch OS employs aggressive battery management that can freeze background alarms. Configure these 4 items:

### A. Autostart Permission
- Navigate to **Settings > Applications and permissions > Permission management > Autostart**.
- Locate **NTC Launcher** and toggle **ON**.

### B. High Background Power Consumption (Battery Saver Exclusion)
- Navigate to **Settings > Battery > Background power consumption management**.
- Find **NTC Launcher**.
- Select **High background power consumption allowed** (Prevents Android from killing the midnight timer).

### C. Accessibility Service for Focus Mode Blocking
- Navigate to **Settings > Accessibility > Downloaded apps > NTC Focus Blocker**.
- Toggle **ON** and tap **Allow** on the system confirmation dialog.

### D. Usage Access for Real App Insights Chart
- Navigate to **Settings > Applications and permissions > Special app access > Usage access**.
- Enable **NTC Launcher**.

---

## 5. Architectural Features & Platform Limitation Disclosures

| Feature Component | Implementation Status | Technical Mechanism |
| :--- | :--- | :--- |
| **Fixed 6 Goal Cards** | ✅ Fully Implemented | Room DB `daily_goals`, fixed slots 0 to 5 |
| **Password-Protected Completion** | ✅ Fully Implemented | Android Keystore + PBKDF2/SHA-256 with cryptographic salt |
| **Automatic Midnight Rollover** | ✅ Fully Implemented | Exact AlarmManager (`RTC_WAKEUP`) + Date reconciliation on app launch |
| **Permanent History (Daily/Weekly/Monthly)** | ✅ Fully Implemented | Room DB `daily_sessions`, denominator strictly 6 per day |
| **Accurate Status Percentages** | ✅ Fully Implemented | Whole-number math: Doing%, Excuse%, Pending% |
| **Explicit User History Reset** | ✅ Fully Implemented | 2-step confirmation warning + PIN requirement |
| **4 Focus Schedules + Overnight** | ✅ Fully Implemented | Handles 23:00 to 06:00 crossing midnight seamlessly |
| **Focus Emergency Access (60s)** | ✅ Fully Implemented | Strict 60s countdown, max 1 allowance per rolling hour |
| **App Time Check (5, 15, 30 mins)** | ✅ Fully Implemented | Strict 3-choice modal (no 4th option) |
| **Clock (~4.28" from bottom)** | ✅ Fully Implemented | 4 distinct digit styles (Double-line, Rounded, Bold, Minimal) |
| **Insights Section (Real Usage)** | ✅ Fully Implemented | Android `UsageStatsManager`, hours/minutes scale |
| **Dock (Phone, Camera, Khan GS)** | ✅ Fully Implemented | Real Intent resolution with package fallback |
| **All Apps & Widgets** | ✅ Fully Implemented | Text-only minimalist package list + AppWidgetHost |
| **Themes & Wallpapers** | ✅ Fully Implemented | 28 curated calm, low-brightness themes |
| **Fonts & Typography** | ✅ Fully Implemented | 32 distinct fonts across Serif, Sans, Mono, and Display |
| **Tamper-Proof Disclosure** | ⚠️ Honest Platform Limitation | On unmanaged consumer Android devices, third-party launchers cannot block ADB or Safe Mode without Device-Owner (MDM) status |
