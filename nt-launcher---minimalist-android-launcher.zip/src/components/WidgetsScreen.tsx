import React, { useState } from 'react';
import { LayoutGrid, Plus, Trash2, ChevronDown, Check, Sparkles, Battery, Calendar, Clock, BookOpen } from 'lucide-react';

interface WidgetItem {
  id: string;
  widgetProvider: string;
  label: string;
  type: 'calendar-agenda' | 'battery-status' | 'study-timer' | 'daily-quote';
  size: 'small' | 'medium' | 'large';
}

const AVAILABLE_WIDGET_CATALOG: Omit<WidgetItem, 'id'>[] = [
  {
    widgetProvider: 'com.ntc.launcher.widget.DailyGlanceProvider',
    label: 'Daily 6-Goal Quick Glance',
    type: 'study-timer',
    size: 'medium',
  },
  {
    widgetProvider: 'com.google.android.calendar.widget',
    label: 'Calendar Agenda & Events',
    type: 'calendar-agenda',
    size: 'large',
  },
  {
    widgetProvider: 'com.android.systemui.battery',
    label: 'Minimalist Battery & Memory',
    type: 'battery-status',
    size: 'small',
  },
  {
    widgetProvider: 'xyz.penpencil.khanglobalstudies.widget',
    label: 'Khan GS Daily Study Streak',
    type: 'daily-quote',
    size: 'medium',
  },
];

interface WidgetsScreenProps {
  onBackToHome: () => void;
}

export const WidgetsScreen: React.FC<WidgetsScreenProps> = ({ onBackToHome }) => {
  const [activeWidgets, setActiveWidgets] = useState<WidgetItem[]>([
    {
      id: 'w-1',
      widgetProvider: 'com.ntc.launcher.widget.DailyGlanceProvider',
      label: 'Daily 6-Goal Quick Glance',
      type: 'study-timer',
      size: 'medium',
    },
    {
      id: 'w-2',
      widgetProvider: 'com.android.systemui.battery',
      label: 'Minimalist Battery & Memory',
      type: 'battery-status',
      size: 'small',
    },
  ]);

  const [catalogOpen, setCatalogOpen] = useState(false);

  const handleAddWidget = (template: Omit<WidgetItem, 'id'>) => {
    const newWidget: WidgetItem = {
      ...template,
      id: `widget_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    };
    setActiveWidgets(prev => [...prev, newWidget]);
    setCatalogOpen(false);
  };

  const handleRemoveWidget = (id: string) => {
    setActiveWidgets(prev => prev.filter(w => w.id !== id));
  };

  return (
    <div className="w-full h-full flex flex-col p-4 sm:p-6 overflow-y-auto text-slate-100 animate-in fade-in slide-in-from-bottom duration-200">
      {/* Top Header */}
      <div className="flex items-center justify-between pb-3 mb-4 border-b border-white/10">
        <div className="flex items-center gap-2">
          <LayoutGrid className="w-4 h-4 text-indigo-400" />
          <h2 className="text-sm font-semibold tracking-wide text-white uppercase">
            Android Widgets Space
          </h2>
        </div>

        <button
          onClick={onBackToHome}
          className="flex items-center gap-1 text-xs text-slate-400 hover:text-white transition-colors py-1 px-2.5 rounded-lg hover:bg-white/5"
        >
          <span>Home</span>
          <ChevronDown className="w-4 h-4" />
        </button>
      </div>

      <div className="flex items-center justify-between mb-4">
        <p className="text-xs text-slate-400">
          AppWidgetHost container • Host ID: 1024
        </p>

        <button
          onClick={() => setCatalogOpen(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-medium text-white transition-colors"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Widget</span>
        </button>
      </div>

      {/* Widget Container Grid */}
      <div className="flex-1 space-y-3">
        {activeWidgets.length === 0 ? (
          <div className="py-16 text-center text-slate-500">
            <LayoutGrid className="w-8 h-8 mx-auto mb-2 opacity-40" />
            <p className="text-xs">No widgets placed yet</p>
            <p className="text-[10px] mt-1 text-slate-600">Tap Add Widget to bind installed providers</p>
          </div>
        ) : (
          activeWidgets.map(widget => (
            <div
              key={widget.id}
              className="rounded-2xl bg-white/[0.04] border border-white/10 p-4 relative group"
            >
              <div className="flex items-center justify-between pb-2 border-b border-white/[0.06] mb-3">
                <span className="text-[11px] font-medium text-slate-300">
                  {widget.label}
                </span>
                <button
                  onClick={() => handleRemoveWidget(widget.id)}
                  className="p-1 rounded-md text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                  title="Remove widget"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Render functional widget representations */}
              {widget.type === 'study-timer' && (
                <div className="flex items-center justify-between py-1 px-2 rounded-xl bg-black/30">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-300 flex items-center justify-center text-xs font-bold font-mono">
                      6
                    </div>
                    <div>
                      <p className="text-xs font-medium text-white">Daily Focus Goals</p>
                      <p className="text-[10px] text-emerald-400">Locked with Password PIN</p>
                    </div>
                  </div>
                  <span className="text-xs font-mono text-slate-400">Today: Active</span>
                </div>
              )}

              {widget.type === 'battery-status' && (
                <div className="flex items-center justify-between py-2 px-3 rounded-xl bg-black/30">
                  <div className="flex items-center gap-2">
                    <Battery className="w-4 h-4 text-emerald-400" />
                    <span className="text-xs font-medium text-white">Vivo V21 Battery</span>
                  </div>
                  <span className="text-xs font-mono font-bold text-emerald-300">88% • Normal</span>
                </div>
              )}

              {widget.type === 'calendar-agenda' && (
                <div className="py-2 px-3 rounded-xl bg-black/30 space-y-1.5">
                  <div className="flex items-center gap-2 text-indigo-300 text-xs font-medium">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>Upcoming Agenda</span>
                  </div>
                  <p className="text-xs text-slate-300">3:30 PM — Khan Global Studies GS Paper II</p>
                  <p className="text-[10px] text-slate-500 font-mono">Synced from Google Calendar</p>
                </div>
              )}

              {widget.type === 'daily-quote' && (
                <div className="py-2 px-3 rounded-xl bg-black/30 space-y-1">
                  <p className="text-xs italic text-amber-200">
                    &quot;Discipline is choosing between what you want now and what you want most.&quot;
                  </p>
                  <p className="text-[10px] text-slate-400 text-right">— Khan GS Motivation</p>
                </div>
              )}

              <p className="text-[9px] font-mono text-slate-600 mt-2 truncate">
                Provider: {widget.widgetProvider}
              </p>
            </div>
          ))
        )}
      </div>

      {/* Catalog Modal */}
      {catalogOpen && (
        <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-2xl bg-[#141620] border border-white/10 p-5 shadow-2xl text-slate-100">
            <h3 className="text-sm font-semibold text-white mb-2">Available AppWidgets</h3>
            <p className="text-xs text-slate-400 mb-4">
              Select an AppWidgetProvider installed on your Android device:
            </p>

            <div className="space-y-2 mb-4">
              {AVAILABLE_WIDGET_CATALOG.map((item, idx) => (
                <button
                  key={idx}
                  onClick={() => handleAddWidget(item)}
                  className="w-full p-3 rounded-xl bg-white/5 hover:bg-white/10 text-left border border-white/5 flex items-center justify-between group transition-colors"
                >
                  <div>
                    <h4 className="text-xs font-medium text-white group-hover:text-indigo-300">
                      {item.label}
                    </h4>
                    <p className="text-[10px] text-slate-400 font-mono">{item.size.toUpperCase()} size</p>
                  </div>
                  <Plus className="w-4 h-4 text-slate-400 group-hover:text-white" />
                </button>
              ))}
            </div>

            <button
              onClick={() => setCatalogOpen(false)}
              className="w-full py-2 rounded-xl border border-white/10 text-xs text-slate-400 hover:text-white"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
