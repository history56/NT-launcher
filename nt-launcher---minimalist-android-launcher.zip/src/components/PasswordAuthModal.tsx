import React, { useState } from 'react';
import { Lock, KeyRound, AlertCircle, CheckCircle2, X } from 'lucide-react';
import { loadPinAuthConfig, verifyPin, setupNewPin } from '../utils/security';

interface PasswordAuthModalProps {
  isOpen: boolean;
  title?: string;
  subtitle?: string;
  onSuccess: () => void;
  onCancel: () => void;
  requireSetupIfNeeded?: boolean;
}

export const PasswordAuthModal: React.FC<PasswordAuthModalProps> = ({
  isOpen,
  title = 'Goal Completion Password Required',
  subtitle = 'Enter your configured PIN to mark this goal as Doing.',
  onSuccess,
  onCancel,
  requireSetupIfNeeded = true,
}) => {
  const [pin, setPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [isSettingUp, setIsSettingUp] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isVerifying, setIsVerifying] = useState(false);

  const authConfig = loadPinAuthConfig();

  if (!isOpen) return null;

  const handleDigit = (digit: string) => {
    if (error) setError(null);
    if (isSettingUp && pin.length >= 4 && confirmPin.length < 4) {
      setConfirmPin(prev => prev + digit);
      return;
    }
    if (pin.length < 6) {
      setPin(prev => prev + digit);
    }
  };

  const handleDelete = () => {
    if (error) setError(null);
    if (isSettingUp && confirmPin.length > 0) {
      setConfirmPin(prev => prev.slice(0, -1));
      return;
    }
    setPin(prev => prev.slice(0, -1));
  };

  const handleClear = () => {
    setPin('');
    setConfirmPin('');
    setError(null);
  };

  const handleSubmit = async () => {
    if (!authConfig.isConfigured) {
      // Setup flow
      if (pin.length < 4) {
        setError('Please enter at least 4 digits for your PIN.');
        return;
      }
      if (confirmPin.length === 0) {
        setIsSettingUp(true);
        setError('Please re-enter your PIN below to confirm.');
        return;
      }
      if (pin !== confirmPin) {
        setError('PINs do not match. Please try again.');
        setConfirmPin('');
        return;
      }
      await setupNewPin(pin);
      handleClear();
      onSuccess();
      return;
    }

    // Verification flow
    if (pin.length < 4) {
      setError('Enter your 4-6 digit PIN.');
      return;
    }

    setIsVerifying(true);
    const valid = await verifyPin(pin, authConfig.salt, authConfig.pinHash);
    setIsVerifying(false);

    if (valid) {
      handleClear();
      onSuccess();
    } else {
      setError('Incorrect password/PIN. Goal status remains unchanged.');
      setPin('');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-sm rounded-2xl bg-[#14161f] border border-white/10 p-6 shadow-2xl text-slate-100">
        <div className="flex items-center justify-between pb-3 border-b border-white/5">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-indigo-500/10 text-indigo-400">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-semibold tracking-wide text-white">{title}</h3>
              <p className="text-xs text-slate-400">Security Verification</p>
            </div>
          </div>
          <button
            onClick={onCancel}
            className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-white/5 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="py-4 text-center">
          <p className="text-xs text-slate-300 leading-relaxed mb-4">
            {!authConfig.isConfigured
              ? 'No Goal Completion PIN configured yet. Create a 4-6 digit security PIN to protect goal completion.'
              : subtitle}
          </p>

          {/* Dots Indicator */}
          <div className="flex justify-center items-center gap-2 mb-2">
            {Array.from({ length: Math.max(4, pin.length) }).map((_, i) => (
              <div
                key={i}
                className={`w-3.5 h-3.5 rounded-full transition-all duration-150 ${
                  i < pin.length
                    ? 'bg-indigo-400 scale-110 shadow-sm shadow-indigo-500/50'
                    : 'bg-white/10'
                }`}
              />
            ))}
          </div>

          {!authConfig.isConfigured && isSettingUp && (
            <div className="mt-3">
              <p className="text-[11px] text-amber-300 mb-2">Confirm PIN:</p>
              <div className="flex justify-center items-center gap-2">
                {Array.from({ length: 4 }).map((_, i) => (
                  <div
                    key={i}
                    className={`w-3 h-3 rounded-full ${
                      i < confirmPin.length ? 'bg-amber-400' : 'bg-white/10'
                    }`}
                  />
                ))}
              </div>
            </div>
          )}

          {error && (
            <div className="flex items-center justify-center gap-1.5 mt-3 text-xs text-rose-400 bg-rose-500/10 py-1.5 px-3 rounded-lg border border-rose-500/20">
              <AlertCircle className="w-3.5 h-3.5 shrink-0" />
              <span>{error}</span>
            </div>
          )}
        </div>

        {/* Numpad */}
        <div className="grid grid-cols-3 gap-2 my-2">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map(num => (
            <button
              key={num}
              onClick={() => handleDigit(num)}
              className="py-3 rounded-xl bg-white/5 hover:bg-white/10 active:scale-95 text-base font-medium transition-all text-slate-200"
            >
              {num}
            </button>
          ))}
          <button
            onClick={handleClear}
            className="py-3 rounded-xl bg-white/5 hover:bg-white/10 active:scale-95 text-xs font-medium text-slate-400 transition-all"
          >
            Clear
          </button>
          <button
            onClick={() => handleDigit('0')}
            className="py-3 rounded-xl bg-white/5 hover:bg-white/10 active:scale-95 text-base font-medium transition-all text-slate-200"
          >
            0
          </button>
          <button
            onClick={handleDelete}
            className="py-3 rounded-xl bg-white/5 hover:bg-white/10 active:scale-95 text-xs font-medium text-slate-400 transition-all"
          >
            ⌫
          </button>
        </div>

        <div className="flex gap-2.5 mt-4 pt-3 border-t border-white/5">
          <button
            onClick={onCancel}
            className="flex-1 py-2.5 rounded-xl border border-white/10 text-xs font-medium text-slate-300 hover:bg-white/5 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={isVerifying || pin.length < 4}
            className="flex-1 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 disabled:hover:bg-indigo-600 text-xs font-medium text-white transition-colors flex items-center justify-center gap-1.5"
          >
            <KeyRound className="w-3.5 h-3.5" />
            <span>{!authConfig.isConfigured ? (isSettingUp ? 'Confirm' : 'Next') : 'Verify'}</span>
          </button>
        </div>

        <p className="text-[10px] text-center text-slate-500 mt-3">
          App-level personal lock • SHA-256 hashed locally
        </p>
      </div>
    </div>
  );
};
