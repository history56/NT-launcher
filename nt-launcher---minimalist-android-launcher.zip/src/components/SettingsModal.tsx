import React, { useState } from 'react';
import {
  Settings,
  Palette,
  Type,
  Clock,
  Lock,
  History,
  Shield,
  Hourglass,
  Layers,
  Smartphone,
  Info,
  Check,
  ChevronRight,
  AlertTriangle,
  KeyRound,
  FileSpreadsheet,
  FileCode,
  Download,
  X,
} from 'lucide-react';
import { ThemeConfig, FontConfig, ClockStyleId } from '../types/launcher';
import { THEMES_LIST, FONTS_LIST, CLOCK_DESIGNS } from '../utils/themesAndFonts';
import { loadPinAuthConfig, setupNewPin, resetPinCredentials, verifyPin } from '../utils/security';
import { resetAllHistory, exportHistoryAsCsv, exportHistoryAsJson } from '../utils/storage';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentTheme: ThemeConfig;
  onSelectTheme: (theme: ThemeConfig) => void;
  currentFont: FontConfig;
  onSelectFont: (font: FontConfig) => void;
  currentClockStyle: ClockStyleId;
  onSelectClockStyle: (style: ClockStyleId) => void;
  onOpenHistoryModal: () => void;
  onOpenTestRunner: () => void;
  onOpenAndroidStudioHub: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  currentTheme,
  onSelectTheme,
  currentFont,
  onSelectFont,
  currentClockStyle,
  onSelectClockStyle,
  onOpenHistoryModal,
  onOpenTestRunner,
  onOpenAndroidStudioHub,
}) => {
  const [activeSection, setActiveSection] = useState<
    | 'themes'
    | 'fonts'
    | 'clock'
    | 'goals-pin'
    | 'history-export'
    | 'focus'
    | 'time-check'
    | 'vivo-permissions'
    | 'about'
  >('themes');

  const [pinConfig, setPinConfig] = useState(loadPinAuthConfig());
  const [newPinInput, setNewPinInput] = useState('');
  const [confirmPinInput, setConfirmPinInput] = useState('');
  const [pinFeedback, setPinFeedback] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSavePin = async () => {
    if (newPinInput.length < 4) {
      setPinFeedback('PIN must be at least 4 digits.');
      return;
    }
    if (newPinInput !== confirmPinInput) {
      setPinFeedback('PINs do not match.');
      return;
    }
    const updated = await setupNewPin(newPinInput);
    setPinConfig(updated);
    setNewPinInput('');
    setConfirmPinInput('');
    setPinFeedback('PIN configured and secured with SHA-256 successfully!');
    setTimeout(() => setPinFeedback(null), 3000);
  };

  const handleResetPin = () => {
    if (confirm('Are you sure you want to reset your Goal Completion PIN? Note: Your goal history will NOT be erased.')) {
      resetPinCredentials();
      setPinConfig(loadPinAuthConfig());
      setPinFeedback('PIN credentials reset. Goals can now be edited or completed freely.');
      setTimeout(() => setPinFeedback(null), 3000);
    }
  };

  return (
    <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/80 backdrop-blur-md p-3 sm:p-4 animate-in fade-in">
      <div className="w-full max-w-2xl max-h-[92vh] flex flex-col rounded-2xl bg-[#0f1118] border border-white/10 shadow-2xl text-slate-100 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/10 bg-white/[0.02]">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400">
              <Settings className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-white tracking-wide">
                NTC Launcher Settings
              </h2>
              <p className="text-xs text-slate-400">Personal customization & system configuration</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Two Column Layout: Navigation Menu on Left, Content on Right */}
        <div className="flex-1 flex flex-col sm:flex-row overflow-hidden">
          {/* Sidebar Menu */}
          <div className="w-full sm:w-52 border-b sm:border-b-0 sm:border-r border-white/10 bg-black/20 p-2 overflow-x-auto sm:overflow-y-auto flex sm:flex-col gap-1 shrink-0">
            {[
              { id: 'themes', label: 'Themes & Wallpapers', icon: Palette },
              { id: 'fonts', label: 'Typography & Fonts', icon: Type },
              { id: 'clock', label: 'Clock Designs', icon: Clock },
              { id: 'goals-pin', label: 'Goal Password/PIN', icon: Lock },
              { id: 'history-export', label: 'History & Backup', icon: History },
              { id: 'focus', label: 'Focus Blocking', icon: Shield },
              { id: 'time-check', label: 'App Time Check', icon: Hourglass },
              { id: 'vivo-permissions', label: 'Vivo V21 Setup', icon: Smartphone },
              { id: 'about', label: 'About & Tests', icon: Info },
            ].map(item => {
              const Icon = item.icon;
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveSection(item.id as any)}
                  className={`flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium transition-all text-left whitespace-nowrap ${
                    isActive
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>

          {/* Settings Section Content */}
          <div className="flex-1 p-5 overflow-y-auto space-y-4">
            {/* 1. THEMES & WALLPAPERS */}
            {activeSection === 'themes' && (
              <div>
                <div className="mb-4">
                  <h3 className="text-sm font-semibold text-white">Themes & Ambient Palettes</h3>
                  <p className="text-xs text-slate-400">
                    28 calm, low-brightness, distraction-free visual themes inspired by deep nature and night skies.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {THEMES_LIST.map(th => {
                    const isSelected = th.id === currentTheme.id;
                    return (
                      <button
                        key={th.id}
                        onClick={() => onSelectTheme(th)}
                        className={`p-3 rounded-xl border text-left transition-all relative overflow-hidden group ${
                          isSelected
                            ? 'border-indigo-400 bg-white/10 ring-1 ring-indigo-400/50'
                            : 'border-white/10 bg-white/[0.03] hover:border-white/20'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1.5">
                          <span className="text-xs font-semibold text-white">{th.name}</span>
                          {isSelected && <Check className="w-3.5 h-3.5 text-indigo-400" />}
                        </div>
                        <p className="text-[10px] text-slate-400 line-clamp-1 mb-2">
                          {th.description}
                        </p>
                        <span className="text-[9px] px-1.5 py-0.5 rounded bg-black/40 text-slate-300 font-mono">
                          {th.category}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* 2. FONTS */}
            {activeSection === 'fonts' && (
              <div>
                <div className="mb-4">
                  <h3 className="text-sm font-semibold text-white">App & UI Fonts</h3>
                  <p className="text-xs text-slate-400">
                    32 distinct font options including Serif, Clean Sans, Monospace, and Editorial styles.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {FONTS_LIST.map(f => {
                    const isSelected = f.id === currentFont.id;
                    return (
                      <button
                        key={f.id}
                        onClick={() => onSelectFont(f)}
                        className={`p-3 rounded-xl border text-left transition-all ${
                          isSelected
                            ? 'border-indigo-400 bg-white/10 ring-1 ring-indigo-400/50'
                            : 'border-white/10 bg-white/[0.03] hover:border-white/20'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs font-medium text-white">{f.name}</span>
                          {isSelected && <Check className="w-3.5 h-3.5 text-indigo-400" />}
                        </div>
                        <p
                          className="text-sm text-slate-200 mt-1 truncate"
                          style={{ fontFamily: f.cssFamily }}
                        >
                          {f.sampleText}
                        </p>
                        <span className="text-[9px] text-slate-500 font-mono mt-1 block">
                          {f.category}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* 3. CLOCK DESIGNS */}
            {activeSection === 'clock' && (
              <div>
                <div className="mb-4">
                  <h3 className="text-sm font-semibold text-white">Home Clock Numeral Designs</h3>
                  <p className="text-xs text-slate-400">
                    4 distinct digit rendering modes placed adaptively in the central screen space.
                  </p>
                </div>

                <div className="space-y-3">
                  {CLOCK_DESIGNS.map(cd => {
                    const isSelected = cd.id === currentClockStyle;
                    return (
                      <button
                        key={cd.id}
                        onClick={() => onSelectClockStyle(cd.id)}
                        className={`w-full p-4 rounded-xl border text-left transition-all flex items-center justify-between ${
                          isSelected
                            ? 'border-indigo-400 bg-white/10 ring-1 ring-indigo-400/50'
                            : 'border-white/10 bg-white/[0.03] hover:border-white/20'
                        }`}
                      >
                        <div>
                          <h4 className="text-sm font-semibold text-white">{cd.name}</h4>
                          <p className="text-xs text-slate-400 mt-0.5">{cd.description}</p>
                        </div>
                        {isSelected && <Check className="w-4 h-4 text-indigo-400" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* 4. GOAL COMPLETION PIN / PASSWORD */}
            {activeSection === 'goals-pin' && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-semibold text-white">Goal Completion Password / PIN</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Protect goal completion so you cannot mark a task as Doing without consciously typing your personal PIN.
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-white/[0.03] border border-white/10">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-medium text-slate-200">Current Status:</span>
                    <span
                      className={`text-xs font-mono font-semibold px-2 py-0.5 rounded ${
                        pinConfig.isConfigured
                          ? 'bg-emerald-500/20 text-emerald-300'
                          : 'bg-amber-500/20 text-amber-300'
                      }`}
                    >
                      {pinConfig.isConfigured ? 'PIN CONFIGURED & ACTIVE' : 'NO PIN SET'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Protected with SHA-256 and salt. Never stored in plain text.
                  </p>
                </div>

                {/* Form to Set / Change PIN */}
                <div className="p-4 rounded-xl bg-black/30 border border-white/10 space-y-3">
                  <h4 className="text-xs font-semibold text-white uppercase tracking-wider">
                    {pinConfig.isConfigured ? 'Change Password/PIN' : 'Create New Password/PIN'}
                  </h4>

                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">New 4-6 Digit PIN:</label>
                    <input
                      type="password"
                      maxLength={6}
                      value={newPinInput}
                      onChange={e => setNewPinInput(e.target.value.replace(/\D/g, ''))}
                      placeholder="Enter 4-6 digits"
                      className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-xs text-white font-mono outline-none focus:border-indigo-400"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">Confirm PIN:</label>
                    <input
                      type="password"
                      maxLength={6}
                      value={confirmPinInput}
                      onChange={e => setConfirmPinInput(e.target.value.replace(/\D/g, ''))}
                      placeholder="Re-enter PIN"
                      className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-xs text-white font-mono outline-none focus:border-indigo-400"
                    />
                  </div>

                  {pinFeedback && (
                    <p className="text-xs text-indigo-300 bg-indigo-500/10 p-2 rounded-lg border border-indigo-500/20">
                      {pinFeedback}
                    </p>
                  )}

                  <div className="flex gap-2 pt-1">
                    <button
                      onClick={handleSavePin}
                      disabled={newPinInput.length < 4}
                      className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-xs font-medium text-white transition-colors"
                    >
                      {pinConfig.isConfigured ? 'Update PIN' : 'Save PIN'}
                    </button>

                    {pinConfig.isConfigured && (
                      <button
                        onClick={handleResetPin}
                        className="px-3 py-2 rounded-xl border border-rose-500/30 text-rose-300 hover:bg-rose-500/10 text-xs transition-colors"
                      >
                        Reset / Remove PIN
                      </button>
                    )}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-900/40 border border-white/5 text-[11px] text-slate-500">
                  <strong>Personal Lock Disclaimer:</strong> This password is an app-level psychological barrier against careless checking. It does not defend against rooted device extraction or physical device-owner tampering.
                </div>
              </div>
            )}

            {/* 5. HISTORY & DATA BACKUP */}
            {activeSection === 'history-export' && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-semibold text-white">History Management & Export</h3>
                  <p className="text-xs text-slate-400">
                    Your goal history is stored permanently in the local database. Export anytime or view full analytics.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-white/[0.03] border border-white/10 space-y-3">
                  <h4 className="text-xs font-semibold text-white uppercase tracking-wider">
                    Full Analytics & Reporting
                  </h4>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    View daily cards, weekly summaries, and monthly chronological breakdowns with exact whole-number Doing, Excuse, and Pending percentage rules.
                  </p>
                  <button
                    onClick={() => {
                      onClose();
                      onOpenHistoryModal();
                    }}
                    className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-medium text-white transition-colors flex items-center gap-2"
                  >
                    <History className="w-4 h-4" />
                    <span>Open History Panel</span>
                  </button>
                </div>

                <div className="p-4 rounded-xl bg-white/[0.03] border border-white/10 space-y-3">
                  <h4 className="text-xs font-semibold text-white uppercase tracking-wider">
                    Local Data Backup
                  </h4>
                  <p className="text-xs text-slate-300">
                    Export your complete historical database to local files:
                  </p>
                  <div className="flex gap-2">
                    <button
                      onClick={() => {
                        const csv = exportHistoryAsCsv();
                        const blob = new Blob([csv], { type: 'text/csv' });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = `NTC_History_${new Date().toISOString().slice(0, 10)}.csv`;
                        a.click();
                      }}
                      className="px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-medium text-white transition-colors flex items-center gap-1.5"
                    >
                      <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Download CSV</span>
                    </button>

                    <button
                      onClick={() => {
                        const json = exportHistoryAsJson();
                        const blob = new Blob([json], { type: 'application/json' });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = `NTC_History_${new Date().toISOString().slice(0, 10)}.json`;
                        a.click();
                      }}
                      className="px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-medium text-white transition-colors flex items-center gap-1.5"
                    >
                      <FileCode className="w-3.5 h-3.5 text-sky-400" />
                      <span>Download JSON</span>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* 6. FOCUS BLOCKING */}
            {activeSection === 'focus' && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-semibold text-white">Focus Mode Architecture</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Recurring schedules, overnight sessions crossing midnight, and 60-second emergency access enforcement.
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-white/[0.03] border border-white/10 space-y-2 text-xs text-slate-300 leading-relaxed">
                  <p><strong>Overnight Scheduling:</strong> Supported out of the box (e.g. 23:00 to 06:00). Android AlarmManager calculates exact UTC epoch stamps across date boundaries.</p>
                  <p><strong>Emergency Access Rule:</strong> Grants strictly 60 seconds, maximum 1 time per hourly window. Keeps the focus session fully alive.</p>
                  <p><strong>Active Session Policy:</strong> No in-app cancel or disable button while a session is active.</p>
                </div>
              </div>
            )}

            {/* 7. APP TIME CHECK */}
            {activeSection === 'time-check' && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-semibold text-white">App Time Check (5, 15, or 30 Mins)</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Prompts when launching monitored apps (YouTube, Chrome, Instagram, etc.) with strictly three choices: 5, 15, or 30 minutes.
                  </p>
                </div>
                <div className="p-3.5 rounded-xl bg-white/[0.03] border border-white/10 text-xs text-slate-300">
                  Separated logically from the Focus scheduling system to encourage intentional screen habits throughout the day.
                </div>
              </div>
            )}

            {/* 8. VIVO V21 SETUP & PERMISSIONS */}
            {activeSection === 'vivo-permissions' && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-semibold text-white">Vivo V21 (Android 12) Funtouch OS Guide</h3>
                  <p className="text-xs text-slate-400">
                    Critical background optimization settings for Vivo devices.
                  </p>
                </div>

                <div className="space-y-2.5 text-xs">
                  <div className="p-3 rounded-xl bg-white/[0.03] border border-white/10">
                    <h4 className="font-semibold text-amber-300 mb-1">1. Autostart Permission</h4>
                    <p className="text-slate-400">Settings &gt; Applications &amp; Permissions &gt; Autostart &gt; Turn ON for NTC Launcher.</p>
                  </div>
                  <div className="p-3 rounded-xl bg-white/[0.03] border border-white/10">
                    <h4 className="font-semibold text-amber-300 mb-1">2. Battery Background Consumption</h4>
                    <p className="text-slate-400">Settings &gt; Battery &gt; Background power consumption management &gt; Select &quot;High background power consumption allowed&quot;.</p>
                  </div>
                  <div className="p-3 rounded-xl bg-white/[0.03] border border-white/10">
                    <h4 className="font-semibold text-amber-300 mb-1">3. Default Home App</h4>
                    <p className="text-slate-400">Settings &gt; Applications &amp; Permissions &gt; Default app settings &gt; Home screen &gt; Select NTC Launcher.</p>
                  </div>
                  <div className="p-3 rounded-xl bg-white/[0.03] border border-white/10">
                    <h4 className="font-semibold text-amber-300 mb-1">4. Accessibility Service for Focus Mode</h4>
                    <p className="text-slate-400">Settings &gt; Accessibility &gt; Downloaded apps &gt; NTC Focus Blocker &gt; Turn ON.</p>
                  </div>
                </div>
              </div>
            )}

            {/* 9. ABOUT & TEST RUNNER */}
            {activeSection === 'about' && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-semibold text-white">About NTC Launcher</h3>
                  <p className="text-xs text-slate-400">Version 1.0.0 (Native Android Studio Project)</p>
                </div>

                <div className="p-4 rounded-xl bg-white/[0.03] border border-white/10 space-y-2 text-xs text-slate-300 leading-relaxed">
                  <p>Built exclusively for personal use. 100% free, no ads, no subscriptions, zero paid APIs or tracking.</p>
                  <p>Jetpack Compose + Room Database + EncryptedSharedPreferences + AccessibilityService.</p>
                </div>

                <div className="flex flex-col sm:flex-row gap-2 pt-2">
                  <button
                    onClick={() => {
                      onClose();
                      onOpenTestRunner();
                    }}
                    className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs font-medium text-white transition-colors flex items-center justify-center gap-2"
                  >
                    <span>Run 20-Point Requirement Tests</span>
                  </button>

                  <button
                    onClick={() => {
                      onClose();
                      onOpenAndroidStudioHub();
                    }}
                    className="flex-1 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-medium text-white transition-colors flex items-center justify-center gap-2"
                  >
                    <span>Inspect Android Studio Code</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
