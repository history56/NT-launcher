import React, { useState, useEffect } from 'react';
import { BarChart3, RefreshCw, ShieldAlert, Sparkles, ChevronRight } from 'lucide-react';
import { ClockStyleId } from '../types/launcher';
import { getUsageStats, refreshUsageStats, isUsageAccessGranted, setUsageAccessGranted } from '../utils/usageStats';

interface ClockAndInsightsSectionProps {
  clockStyle: ClockStyleId;
  clockFontFamily?: string;
  insightsFontFamily?: string;
  onOpenInsightsSettings?: () => void;
}

export const ClockAndInsightsSection: React.FC<ClockAndInsightsSectionProps> = ({
  clockStyle,
  clockFontFamily,
  insightsFontFamily,
  onOpenInsightsSettings,
}) => {
  const [time, setTime] = useState(new Date());
  const [activeTab, setActiveTab] = useState<'daily' | 'weekly'>('daily');
  const [usageData, setUsageData] = useState(getUsageStats());
  const [hasPermission, setHasPermission] = useState(isUsageAccessGranted());
  const [isRefreshing, setIsRefreshing] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      const updated = refreshUsageStats();
      setUsageData([...updated]);
      setIsRefreshing(false);
    }, 300);
  };

  const togglePermission = () => {
    const next = !hasPermission;
    setUsageAccessGranted(next);
    setHasPermission(next);
  };

  const hoursStr = String(time.getHours()).padStart(2, '0');
  const minutesStr = String(time.getMinutes()).padStart(2, '0');
  const dateFormatted = time.toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  });

  // Render clock digits based on selected style
  const renderClockDigits = () => {
    const digitClassMap: Record<ClockStyleId, string> = {
      'double-line': 'font-mono tracking-tight text-white drop-shadow-[0_2px_10px_rgba(255,255,255,0.15)] [text-shadow:_0_0_1px_rgba(255,255,255,0.8),_0_0_2px_rgba(255,255,255,0.4)]',
      'rounded-deco': 'font-sans font-light tracking-wide text-slate-100',
      'bold-rounded': 'font-black tracking-tighter text-white drop-shadow-md',
      'minimal-outline': 'font-extralight tracking-widest text-slate-200 opacity-90',
    };

    return (
      <div
        className={`flex items-baseline justify-center gap-1 text-5xl sm:text-6xl select-none ${digitClassMap[clockStyle]}`}
        style={{ fontFamily: clockFontFamily }}
      >
        <span>{hoursStr}</span>
        <span className="opacity-40 animate-pulse">:</span>
        <span>{minutesStr}</span>
      </div>
    );
  };

  // Find max usage for scaling the chart
  const maxMinutes = Math.max(
    ...usageData.map(d => (activeTab === 'daily' ? d.usageMinutesToday : d.usageMinutesWeek)),
    180
  );

  return (
    <div className="w-full flex flex-col items-center my-auto py-2">
      {/* Clock display placed adaptively in the central area */}
      <div className="flex flex-col items-center mb-3">
        {renderClockDigits()}
        <span
          className="text-[11px] font-medium tracking-widest text-slate-400 uppercase mt-0.5"
          style={{ fontFamily: clockFontFamily }}
        >
          {dateFormatted}
        </span>
      </div>

      {/* Insights Section: Real App Usage Stats */}
      <div
        className="w-full max-w-sm rounded-xl bg-white/[0.03] border border-white/10 p-2.5 backdrop-blur-sm shadow-sm"
        style={{ fontFamily: insightsFontFamily }}
      >
        <div className="flex items-center justify-between pb-1.5 mb-1.5 border-b border-white/[0.06]">
          <div className="flex items-center gap-1.5">
            <BarChart3 className="w-3.5 h-3.5 text-indigo-400" />
            <span className="text-[11px] font-semibold text-slate-200 tracking-wide uppercase">
              Insights • App Usage
            </span>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex bg-white/5 rounded-md p-0.5 text-[9px]">
              <button
                onClick={() => setActiveTab('daily')}
                className={`px-1.5 py-0.5 rounded transition-all ${
                  activeTab === 'daily'
                    ? 'bg-white/15 text-white font-medium'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Daily
              </button>
              <button
                onClick={() => setActiveTab('weekly')}
                className={`px-1.5 py-0.5 rounded transition-all ${
                  activeTab === 'weekly'
                    ? 'bg-white/15 text-white font-medium'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Weekly
              </button>
            </div>

            <button
              onClick={handleRefresh}
              className={`p-1 rounded text-slate-400 hover:text-white hover:bg-white/5 transition-all ${
                isRefreshing ? 'animate-spin text-indigo-400' : ''
              }`}
              title="Refresh real UsageStats"
            >
              <RefreshCw className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Permission Notice or Chart */}
        {!hasPermission ? (
          <div className="py-2.5 px-2 rounded-lg bg-amber-500/10 border border-amber-500/20 text-center">
            <div className="flex items-center justify-center gap-1 text-amber-300 text-[11px] font-medium mb-1">
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>Usage Access Required</span>
            </div>
            <p className="text-[10px] text-slate-300 leading-tight mb-2">
              Android UsageStatsManager requires explicit permission in system settings to read app screen time.
            </p>
            <button
              onClick={togglePermission}
              className="text-[10px] bg-amber-600/80 hover:bg-amber-500 text-white font-medium px-2.5 py-1 rounded transition-colors"
            >
              Grant Usage Access
            </button>
          </div>
        ) : (
          <div className="relative pt-1 pb-0.5">
            {/* Chart Area with readable vertical scale on left and app names along bottom */}
            <div className="flex items-end gap-1.5 h-20 w-full pl-6 pr-1 relative">
              {/* Vertical Scale on Left */}
              <div className="absolute left-0 inset-y-0 flex flex-col justify-between text-[8px] font-mono text-slate-500 select-none pb-4">
                <span>{Math.round(maxMinutes / 60)}h</span>
                <span>{Math.round((maxMinutes / 2) / 60)}h</span>
                <span>0m</span>
              </div>

              {/* Grid Lines */}
              <div className="absolute left-6 right-1 top-0 border-b border-white/[0.04]" />
              <div className="absolute left-6 right-1 top-1/2 border-b border-white/[0.04]" />
              <div className="absolute left-6 right-1 bottom-4 border-b border-white/10" />

              {/* Bars */}
              {usageData.map((item, i) => {
                const mins = activeTab === 'daily' ? item.usageMinutesToday : item.usageMinutesWeek;
                const heightPercent = Math.max(6, Math.min(100, Math.round((mins / maxMinutes) * 100)));
                const hours = Math.floor(mins / 60);
                const remMins = mins % 60;
                const formattedTime = hours > 0 ? `${hours}h ${remMins}m` : `${remMins}m`;

                return (
                  <div
                    key={item.packageName}
                    className="flex-1 flex flex-col items-center h-full justify-end group z-10"
                    title={`${item.appName}: ${formattedTime} (${item.lastTimeUsed})`}
                  >
                    {/* Time tooltip on hover */}
                    <span className="text-[7px] text-slate-400 group-hover:text-white font-mono opacity-0 group-hover:opacity-100 transition-opacity mb-0.5">
                      {hours > 0 ? `${hours}h` : `${remMins}m`}
                    </span>

                    {/* Bar */}
                    <div
                      className="w-full rounded-t transition-all duration-300 group-hover:brightness-125"
                      style={{
                        height: `${heightPercent * 0.7}%`,
                        backgroundColor:
                          i === 0
                            ? 'rgba(99, 102, 241, 0.8)'
                            : i === 1
                            ? 'rgba(239, 68, 68, 0.75)'
                            : i === 2
                            ? 'rgba(59, 130, 246, 0.75)'
                            : i === 3
                            ? 'rgba(34, 197, 94, 0.75)'
                            : 'rgba(168, 85, 247, 0.7)',
                      }}
                    />

                    {/* App Name along bottom */}
                    <span className="text-[8px] text-slate-300 group-hover:text-white truncate max-w-full mt-1 font-medium tracking-tight">
                      {item.appName}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
