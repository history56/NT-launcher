import React from 'react';
import { Hourglass, Clock, X } from 'lucide-react';
import { setAppTimeLimit } from '../utils/focusManager';

interface AppTimeCheckModalProps {
  isOpen: boolean;
  appName: string;
  onSelectDuration: (durationMinutes: 5 | 15 | 30) => void;
  onCancel: () => void;
}

export const AppTimeCheckModal: React.FC<AppTimeCheckModalProps> = ({
  isOpen,
  appName,
  onSelectDuration,
  onCancel,
}) => {
  if (!isOpen) return null;

  const handleSelect = (mins: 5 | 15 | 30) => {
    setAppTimeLimit(appName, mins);
    onSelectDuration(mins);
  };

  return (
    <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-in fade-in">
      <div className="w-full max-w-xs rounded-2xl bg-[#141620] border border-white/10 p-5 shadow-2xl text-slate-100 text-center">
        <div className="flex items-center justify-between pb-3 border-b border-white/5 mb-3">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-indigo-500/10 text-indigo-400">
              <Hourglass className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-semibold text-white">App Time Check</h3>
          </div>
          <button
            onClick={onCancel}
            className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-white/5"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="text-xs text-slate-300 mb-1">
          How long do you intend to use <strong className="text-white">{appName}</strong>?
        </p>
        <p className="text-[11px] text-slate-500 mb-4">
          Choose a planned duration to stay conscious of screen time:
        </p>

        {/* Strictly THREE choices: 5 minutes, 15 minutes, 30 minutes. No fourth duration option! */}
        <div className="space-y-2 mb-4">
          <button
            onClick={() => handleSelect(5)}
            className="w-full py-2.5 px-4 rounded-xl bg-white/5 hover:bg-indigo-600/30 border border-white/10 hover:border-indigo-500/40 text-xs font-medium text-white transition-all flex items-center justify-between group active:scale-95"
          >
            <div className="flex items-center gap-2">
              <Clock className="w-3.5 h-3.5 text-indigo-400 group-hover:scale-110 transition-transform" />
              <span>5 Minutes</span>
            </div>
            <span className="text-[10px] text-slate-400 font-mono">Quick check</span>
          </button>

          <button
            onClick={() => handleSelect(15)}
            className="w-full py-2.5 px-4 rounded-xl bg-white/5 hover:bg-indigo-600/30 border border-white/10 hover:border-indigo-500/40 text-xs font-medium text-white transition-all flex items-center justify-between group active:scale-95"
          >
            <div className="flex items-center gap-2">
              <Clock className="w-3.5 h-3.5 text-indigo-400 group-hover:scale-110 transition-transform" />
              <span>15 Minutes</span>
            </div>
            <span className="text-[10px] text-slate-400 font-mono">Standard break</span>
          </button>

          <button
            onClick={() => handleSelect(30)}
            className="w-full py-2.5 px-4 rounded-xl bg-white/5 hover:bg-indigo-600/30 border border-white/10 hover:border-indigo-500/40 text-xs font-medium text-white transition-all flex items-center justify-between group active:scale-95"
          >
            <div className="flex items-center gap-2">
              <Clock className="w-3.5 h-3.5 text-indigo-400 group-hover:scale-110 transition-transform" />
              <span>30 Minutes</span>
            </div>
            <span className="text-[10px] text-slate-400 font-mono">Deep session</span>
          </button>
        </div>

        <button
          onClick={onCancel}
          className="text-xs text-slate-400 hover:text-white py-1"
        >
          Cancel
        </button>
      </div>
    </div>
  );
};
