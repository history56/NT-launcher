import React, { useState } from 'react';
import {
  History,
  Calendar,
  BarChart2,
  Download,
  Trash2,
  X,
  CheckCircle2,
  AlertTriangle,
  ChevronDown,
  ChevronRight,
  Clock,
  FileSpreadsheet,
  FileCode,
  ShieldAlert,
} from 'lucide-react';
import { HistoryDailyRecord } from '../types/launcher';
import {
  getFullDailyHistoryRecords,
  resetAllHistory,
  exportHistoryAsCsv,
  exportHistoryAsJson,
} from '../utils/storage';
import { PasswordAuthModal } from './PasswordAuthModal';

interface HistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onHistoryReset: () => void;
}

export const HistoryModal: React.FC<HistoryModalProps> = ({
  isOpen,
  onClose,
  onHistoryReset,
}) => {
  const [activeTab, setActiveTab] = useState<'daily' | 'weekly' | 'monthly'>('daily');
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [expandedMonth, setExpandedMonth] = useState<string | null>(null);

  // Reset confirmation state
  const [resetConfirmOpen, setResetConfirmOpen] = useState(false);
  const [authForResetOpen, setAuthForResetOpen] = useState(false);
  const [resetSuccessNotice, setResetSuccessNotice] = useState(false);

  if (!isOpen) return null;

  const records = getFullDailyHistoryRecords();

  // Helper to format date nicely
  const formatDateLabel = (dateStr: string) => {
    try {
      const [y, m, d] = dateStr.split('-').map(Number);
      const date = new Date(y, m - 1, d);
      return date.toLocaleDateString('en-US', {
        weekday: 'short',
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      });
    } catch {
      return dateStr;
    }
  };

  // Group into calendar weeks (Sunday to Saturday or 7-day slices)
  const getWeeklyGroups = () => {
    const weeks: {
      weekKey: string;
      weekLabel: string;
      days: HistoryDailyRecord[];
      totalSlots: number;
      doingCount: number;
      excuseCount: number;
      pendingCount: number;
      doingPercent: number;
      excusePercent: number;
      pendingPercent: number;
    }[] = [];

    // Chunk records into sets of 7 days
    const chunkSize = 7;
    for (let i = 0; i < records.length; i += chunkSize) {
      const slice = records.slice(i, i + chunkSize);
      const totalSlots = slice.length * 6;
      const doingCount = slice.reduce((acc, r) => acc + r.doingCount, 0);
      const excuseCount = slice.reduce((acc, r) => acc + r.excuseCount, 0);
      const pendingCount = slice.reduce((acc, r) => acc + r.pendingCount, 0);

      const doingPercent = Math.round((doingCount / totalSlots) * 100);
      const excusePercent = Math.round((excuseCount / totalSlots) * 100);
      const pendingPercent = Math.round((pendingCount / totalSlots) * 100);

      const startDate = slice[slice.length - 1].date;
      const endDate = slice[0].date;

      weeks.push({
        weekKey: `week_${i}`,
        weekLabel: `${formatDateLabel(startDate)} — ${formatDateLabel(endDate)}`,
        days: slice,
        totalSlots,
        doingCount,
        excuseCount,
        pendingCount,
        doingPercent,
        excusePercent,
        pendingPercent,
      });
    }

    return weeks;
  };

  // Group by Calendar Month & Year (e.g. October 2026)
  const getMonthlyGroups = () => {
    const monthsMap: Record<string, HistoryDailyRecord[]> = {};

    records.forEach(r => {
      const [y, m] = r.date.split('-');
      const monthKey = `${y}-${m}`;
      if (!monthsMap[monthKey]) monthsMap[monthKey] = [];
      monthsMap[monthKey].push(r);
    });

    return Object.entries(monthsMap).map(([key, monthRecords]) => {
      const [year, month] = key.split('-').map(Number);
      const dateObj = new Date(year, month - 1, 1);
      const monthLabel = dateObj.toLocaleDateString('en-US', {
        month: 'long',
        year: 'numeric',
      });

      const totalSlots = monthRecords.length * 6;
      const doingCount = monthRecords.reduce((acc, r) => acc + r.doingCount, 0);
      const excuseCount = monthRecords.reduce((acc, r) => acc + r.excuseCount, 0);
      const pendingCount = monthRecords.reduce((acc, r) => acc + r.pendingCount, 0);

      const doingPercent = Math.round((doingCount / totalSlots) * 100);
      const excusePercent = Math.round((excuseCount / totalSlots) * 100);
      const pendingPercent = Math.round((pendingCount / totalSlots) * 100);

      return {
        monthKey: key,
        monthLabel,
        days: monthRecords,
        totalSlots,
        doingCount,
        excuseCount,
        pendingCount,
        doingPercent,
        excusePercent,
        pendingPercent,
      };
    });
  };

  // Handle Export CSV
  const handleDownloadCsv = () => {
    const csvContent = exportHistoryAsCsv();
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `NTC_Launcher_History_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Handle Export JSON
  const handleDownloadJson = () => {
    const jsonContent = exportHistoryAsJson();
    const blob = new Blob([jsonContent], { type: 'application/json;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `NTC_Launcher_History_${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Reset confirmation initiated
  const handleInitiateReset = () => {
    setResetConfirmOpen(true);
  };

  const handleConfirmedResetStep1 = () => {
    setResetConfirmOpen(false);
    // Proceed to PIN requirement
    setAuthForResetOpen(true);
  };

  const handleAuthResetSuccess = () => {
    setAuthForResetOpen(false);
    resetAllHistory();
    setResetSuccessNotice(true);
    onHistoryReset();
    setTimeout(() => {
      setResetSuccessNotice(false);
    }, 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-3 sm:p-4 animate-in fade-in">
      <div className="w-full max-w-2xl max-h-[92vh] flex flex-col rounded-2xl bg-[#0f1118] border border-white/10 shadow-2xl text-slate-100 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/10 bg-white/[0.02]">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400">
              <History className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-white tracking-wide">
                Permanent History & Analytics
              </h2>
              <p className="text-xs text-slate-400">
                Persistent local records • Fixed 6 goal slots per day
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadCsv}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-xs text-slate-300 hover:text-white transition-colors"
              title="Export as CSV"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden sm:inline">CSV</span>
            </button>

            <button
              onClick={handleDownloadJson}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-xs text-slate-300 hover:text-white transition-colors"
              title="Export as JSON"
            >
              <FileCode className="w-3.5 h-3.5 text-sky-400" />
              <span className="hidden sm:inline">JSON</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors ml-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center justify-between px-5 py-2.5 bg-black/30 border-b border-white/5">
          <div className="flex bg-white/5 rounded-xl p-1 gap-1">
            <button
              onClick={() => setActiveTab('daily')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                activeTab === 'daily'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Daily Records
            </button>
            <button
              onClick={() => setActiveTab('weekly')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                activeTab === 'weekly'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Weekly Summary
            </button>
            <button
              onClick={() => setActiveTab('monthly')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                activeTab === 'monthly'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Monthly Summary
            </button>
          </div>

          <button
            onClick={handleInitiateReset}
            className="flex items-center gap-1 text-[11px] text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 px-2.5 py-1.5 rounded-lg transition-colors border border-rose-500/20"
            title="Reset All History (Requires Password/PIN)"
          >
            <Trash2 className="w-3 h-3" />
            <span>Reset History</span>
          </button>
        </div>

        {/* Reset Success Notice */}
        {resetSuccessNotice && (
          <div className="mx-5 my-2 p-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4" />
            <span>Historical records reset successfully. New clean session initialized.</span>
          </div>
        )}

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {/* TAB 1: DAILY HISTORY */}
          {activeTab === 'daily' && (
            <div className="space-y-3">
              {records.map(record => (
                <div
                  key={record.date}
                  className="rounded-xl bg-white/[0.03] border border-white/10 p-3.5 hover:border-white/20 transition-all"
                >
                  {/* Day Header with accurate Doing %, Excuse %, Pending % */}
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 border-b border-white/[0.06]">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-indigo-400" />
                      <span className="text-sm font-medium text-white">
                        {formatDateLabel(record.date)}
                      </span>
                      {record.isProvisional && (
                        <span className="text-[10px] font-semibold tracking-wider text-amber-300 bg-amber-500/15 border border-amber-500/30 px-2 py-0.5 rounded-full">
                          TODAY • PROVISIONAL
                        </span>
                      )}
                    </div>

                    {/* Exact Percentage Metrics (Denominator is strictly 6) */}
                    <div className="flex items-center gap-3 text-xs font-mono">
                      <span className="text-emerald-400">
                        Doing: <strong className="font-semibold">{record.doingPercent}%</strong> ({record.doingCount}/6)
                      </span>
                      <span className="text-amber-400">
                        Excuse: <strong className="font-semibold">{record.excusePercent}%</strong> ({record.excuseCount}/6)
                      </span>
                      <span className="text-slate-400">
                        Pending: <strong className="font-semibold">{record.pendingPercent}%</strong> ({record.pendingCount}/6)
                      </span>
                    </div>
                  </div>

                  {/* 6 Goals for that date */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2.5">
                    {record.goals.map((g, slotIdx) => (
                      <div
                        key={g.id || slotIdx}
                        className={`flex items-start justify-between p-2 rounded-lg text-xs ${
                          g.status === 'doing'
                            ? 'bg-emerald-950/20 border border-emerald-500/20 text-emerald-100'
                            : g.status === 'excuse'
                            ? 'bg-amber-950/20 border border-amber-500/20 text-amber-100'
                            : 'bg-white/[0.02] border border-white/5 text-slate-300'
                        }`}
                      >
                        <div className="flex-1 pr-2">
                          <span className="text-[10px] font-mono text-slate-500 mr-1.5">
                            #{slotIdx + 1}
                          </span>
                          <span className={g.status === 'excuse' ? 'line-through opacity-75' : ''}>
                            {g.title || <em className="text-slate-500 font-normal">Unspecified goal</em>}
                          </span>
                          {g.excuseReason && (
                            <p className="text-[10px] text-amber-400/80 italic mt-0.5">
                              Excuse: {g.excuseReason}
                            </p>
                          )}
                        </div>

                        <div className="text-right shrink-0">
                          <span
                            className={`text-[9px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded ${
                              g.status === 'doing'
                                ? 'bg-emerald-500/20 text-emerald-300'
                                : g.status === 'excuse'
                                ? 'bg-amber-500/20 text-amber-300'
                                : 'bg-white/10 text-slate-400'
                            }`}
                          >
                            {g.status === 'doing' ? 'Doing' : g.status === 'excuse' ? 'Excuse' : 'Pending'}
                          </span>
                          {g.completedAt && (
                            <p className="text-[9px] text-slate-400 font-mono mt-0.5">
                              {new Date(g.completedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* TAB 2: WEEKLY SUMMARY */}
          {activeTab === 'weekly' && (
            <div className="space-y-4">
              <p className="text-xs text-slate-400 leading-relaxed">
                Weekly statistics aggregate all 6 goal slots per calendar day across each 7-day reporting period.
              </p>
              {getWeeklyGroups().map(w => (
                <div
                  key={w.weekKey}
                  className="rounded-xl bg-white/[0.03] border border-white/10 p-4"
                >
                  <div className="flex flex-wrap items-center justify-between pb-3 border-b border-white/[0.06] gap-2">
                    <div>
                      <h4 className="text-sm font-semibold text-white">{w.weekLabel}</h4>
                      <p className="text-xs text-slate-400">
                        {w.days.length} days recorded • Total {w.totalSlots} goal slots
                      </p>
                    </div>

                    <div className="flex items-center gap-3 text-xs font-mono">
                      <div className="text-right">
                        <span className="text-emerald-400 font-semibold">{w.doingPercent}%</span>
                        <p className="text-[10px] text-slate-500">Doing ({w.doingCount})</p>
                      </div>
                      <div className="text-right">
                        <span className="text-amber-400 font-semibold">{w.excusePercent}%</span>
                        <p className="text-[10px] text-slate-500">Excuse ({w.excuseCount})</p>
                      </div>
                      <div className="text-right">
                        <span className="text-slate-400 font-semibold">{w.pendingPercent}%</span>
                        <p className="text-[10px] text-slate-500">Pending ({w.pendingCount})</p>
                      </div>
                    </div>
                  </div>

                  {/* Visual Stacked Progress Bar */}
                  <div className="h-3 w-full rounded-full bg-white/5 flex overflow-hidden my-3">
                    <div
                      style={{ width: `${w.doingPercent}%` }}
                      className="bg-emerald-500 transition-all duration-300"
                      title={`Doing: ${w.doingPercent}%`}
                    />
                    <div
                      style={{ width: `${w.excusePercent}%` }}
                      className="bg-amber-500 transition-all duration-300"
                      title={`Excuse: ${w.excusePercent}%`}
                    />
                    <div
                      style={{ width: `${w.pendingPercent}%` }}
                      className="bg-slate-600 transition-all duration-300"
                      title={`Pending: ${w.pendingPercent}%`}
                    />
                  </div>

                  {/* Daily breakdown within week */}
                  <div className="flex flex-wrap gap-2 text-[11px] pt-1">
                    {w.days.map(d => (
                      <div
                        key={d.date}
                        className="px-2 py-1 rounded bg-black/30 border border-white/5 text-slate-300 flex items-center gap-1.5"
                      >
                        <span>{d.date.slice(5)}:</span>
                        <span className="text-emerald-400 font-mono">{d.doingPercent}%</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* TAB 3: MONTHLY SUMMARY */}
          {activeTab === 'monthly' && (
            <div className="space-y-4">
              <p className="text-xs text-slate-400 leading-relaxed">
                Monthly statistics group all calendar days in each month. Denominator equals 6 times total calendar days.
              </p>
              {getMonthlyGroups().map(m => {
                const isExpanded = expandedMonth === m.monthKey;
                return (
                  <div
                    key={m.monthKey}
                    className="rounded-xl bg-white/[0.03] border border-white/10 p-4 transition-all"
                  >
                    <div
                      className="flex flex-wrap items-center justify-between cursor-pointer gap-2"
                      onClick={() => setExpandedMonth(isExpanded ? null : m.monthKey)}
                    >
                      <div className="flex items-center gap-2">
                        {isExpanded ? (
                          <ChevronDown className="w-4 h-4 text-indigo-400" />
                        ) : (
                          <ChevronRight className="w-4 h-4 text-slate-400" />
                        )}
                        <div>
                          <h4 className="text-sm font-semibold text-white">{m.monthLabel}</h4>
                          <p className="text-xs text-slate-400">
                            {m.days.length} days recorded • {m.totalSlots} total goal slots
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 text-xs font-mono">
                        <span className="text-emerald-400 font-medium">
                          Doing: <strong>{m.doingPercent}%</strong> ({m.doingCount})
                        </span>
                        <span className="text-amber-400 font-medium">
                          Excuse: <strong>{m.excusePercent}%</strong> ({m.excuseCount})
                        </span>
                        <span className="text-slate-400 font-medium">
                          Pending: <strong>{m.pendingPercent}%</strong> ({m.pendingCount})
                        </span>
                      </div>
                    </div>

                    {/* Progress Bar */}
                    <div className="h-2.5 w-full rounded-full bg-white/5 flex overflow-hidden mt-3 mb-2">
                      <div style={{ width: `${m.doingPercent}%` }} className="bg-emerald-500" />
                      <div style={{ width: `${m.excusePercent}%` }} className="bg-amber-500" />
                      <div style={{ width: `${m.pendingPercent}%` }} className="bg-slate-600" />
                    </div>

                    {/* Expanded Daily records for this month */}
                    {isExpanded && (
                      <div className="mt-4 pt-3 border-t border-white/10 space-y-2">
                        <p className="text-[11px] text-slate-400 font-medium uppercase tracking-wider mb-2">
                          Daily Records in {m.monthLabel}:
                        </p>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {m.days.map(d => (
                            <div
                              key={d.date}
                              className="p-2 rounded-lg bg-black/40 border border-white/5 text-xs flex items-center justify-between"
                            >
                              <div>
                                <span className="font-medium text-slate-200">{d.date}</span>
                                {d.isProvisional && (
                                  <span className="text-[9px] text-amber-400 ml-1.5">(Today)</span>
                                )}
                              </div>
                              <div className="flex items-center gap-2 font-mono text-[11px]">
                                <span className="text-emerald-400">{d.doingPercent}% Doing</span>
                                <span className="text-slate-500">•</span>
                                <span className="text-amber-400">{d.excuseCount} Exc</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="px-5 py-3 border-t border-white/10 bg-black/40 text-[11px] text-slate-500 flex items-center justify-between">
          <span>Permanent Room database • Daily midnight rollover preserved</span>
          <span>Personal use only • Zero telemetry</span>
        </div>
      </div>

      {/* STEP 1: RESET CONFIRMATION WARNING */}
      {resetConfirmOpen && (
        <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/85 backdrop-blur-md p-4">
          <div className="w-full max-w-sm rounded-2xl bg-[#17131e] border border-rose-500/30 p-5 shadow-2xl text-slate-100">
            <div className="flex items-center gap-2.5 text-rose-400 mb-3">
              <AlertTriangle className="w-5 h-5 shrink-0" />
              <h3 className="text-sm font-semibold text-white">Permanently Reset History?</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed mb-4">
              <strong>Warning:</strong> This operation will permanently delete all saved daily, weekly, and monthly goal records from your local database.
              <br /><br />
              Normal midnight resets and theme changes never clear history. Only this explicit manual reset deletes records.
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => setResetConfirmOpen(false)}
                className="flex-1 py-2 rounded-xl border border-white/10 text-xs text-slate-300 hover:bg-white/5"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmedResetStep1}
                className="flex-1 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-xs font-medium text-white"
              >
                Proceed to Auth
              </button>
            </div>
          </div>
        </div>
      )}

      {/* STEP 2: PIN REQUIREMENT TO FINALIZE RESET */}
      <PasswordAuthModal
        isOpen={authForResetOpen}
        title="Verify PIN to Reset History"
        subtitle="Enter your Goal Completion PIN to authorize permanent deletion of historical records."
        onSuccess={handleAuthResetSuccess}
        onCancel={() => setAuthForResetOpen(false)}
      />
    </div>
  );
};
