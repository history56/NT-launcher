import React, { useState, useEffect } from 'react';
import {
  Flame,
  Clock,
  Shield,
  ShieldCheck,
  AlertTriangle,
  Play,
  CheckCircle2,
  Calendar,
  Layers,
  ChevronLeft,
  Sparkles,
} from 'lucide-react';
import { FocusSchedule, FocusSessionState } from '../types/launcher';
import {
  loadFocusSchedules,
  saveFocusSchedules,
  loadFocusState,
  startManualFocusSession,
  getNextScheduleInfo,
  evaluateFocusStatus,
} from '../utils/focusManager';

interface FocusScreenProps {
  onBackToHome: () => void;
  onSimulateAppLaunch: (appName: string) => void;
}

export const FocusScreen: React.FC<FocusScreenProps> = ({
  onBackToHome,
  onSimulateAppLaunch,
}) => {
  const [schedules, setSchedules] = useState<FocusSchedule[]>(loadFocusSchedules());
  const [focusState, setFocusState] = useState<FocusSessionState>(loadFocusState());
  const [customMinutes, setCustomMinutes] = useState('45');
  const [nextInfo, setNextInfo] = useState(getNextScheduleInfo(schedules));

  // Edit schedule state
  const [editingScheduleId, setEditingScheduleId] = useState<string | null>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      const updated = evaluateFocusStatus(schedules);
      setFocusState({ ...updated });
      setNextInfo(getNextScheduleInfo(schedules));
    }, 2000);
    return () => clearInterval(interval);
  }, [schedules]);

  const handleToggleSchedule = (id: string) => {
    // Cannot disable schedule IF that exact schedule is currently active
    if (focusState.isActive && focusState.scheduleId === id) {
      alert('This schedule is currently active! Once active, focus sessions cannot be cancelled or disabled.');
      return;
    }

    const updated = schedules.map(s => {
      if (s.id === id) return { ...s, isEnabled: !s.isEnabled };
      return s;
    });
    setSchedules(updated);
    saveFocusSchedules(updated);
    setNextInfo(getNextScheduleInfo(updated));
  };

  const handleUpdateTime = (id: string, start: string, end: string) => {
    const updated = schedules.map(s => {
      if (s.id === id) return { ...s, startTime: start, endTime: end };
      return s;
    });
    setSchedules(updated);
    saveFocusSchedules(updated);
    setNextInfo(getNextScheduleInfo(updated));
    setEditingScheduleId(null);
  };

  const handleStartManual = (minutes: number) => {
    if (focusState.isActive) return;
    const defaultBlocked = ['YouTube', 'Instagram', 'Chrome', 'Facebook', 'WhatsApp', 'Twitter/X'];
    const started = startManualFocusSession(minutes, defaultBlocked);
    setFocusState({ ...started });
  };

  // Remaining manual countdown
  const getRemainingTimeDisplay = () => {
    if (!focusState.expiresAt) return null;
    const diffMs = focusState.expiresAt - Date.now();
    if (diffMs <= 0) return 'Session concluding...';
    const totalMins = Math.ceil(diffMs / (60 * 1000));
    const h = Math.floor(totalMins / 60);
    const m = totalMins % 60;
    return h > 0 ? `${h}h ${m}m remaining` : `${m} minutes remaining`;
  };

  return (
    <div className="w-full h-full flex flex-col p-4 sm:p-6 overflow-y-auto text-slate-100 animate-in fade-in slide-in-from-right duration-200">
      {/* Top Navigation */}
      <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
        <button
          onClick={onBackToHome}
          className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-white transition-colors py-1 px-2 rounded-lg hover:bg-white/5"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Home</span>
        </button>

        <div className="flex items-center gap-2">
          <Flame className="w-4 h-4 text-amber-400" />
          <h2 className="text-sm font-semibold tracking-wide text-white">Focus Mode</h2>
        </div>

        <div className="w-12 text-right">
          <span className="text-[10px] font-mono text-slate-500">Swipe ◄</span>
        </div>
      </div>

      {/* ACTIVE SESSION BANNER (OR NEXT UP) */}
      {focusState.isActive ? (
        <div className="w-full p-4 rounded-2xl bg-amber-950/30 border border-amber-500/40 shadow-lg shadow-amber-950/50 mb-5 relative overflow-hidden">
          <div className="flex items-center gap-2.5 text-amber-400 mb-2">
            <Shield className="w-5 h-5 animate-pulse" />
            <h3 className="text-sm font-bold tracking-wide uppercase text-white">
              {focusState.name || 'Focus Session Active'}
            </h3>
          </div>

          <p className="text-xs text-amber-200/90 leading-relaxed mb-3">
            Apps are strictly blocked by AccessibilityService.
            {focusState.expiresAt && (
              <span className="font-mono ml-1 font-bold text-white">
                ({getRemainingTimeDisplay()})
              </span>
            )}
          </p>

          <div className="p-2.5 rounded-xl bg-black/40 border border-white/5 text-[11px] text-slate-400">
            <strong>Design Policy:</strong> Once a session is active, no in-app cancel or disable button is provided. Focus will end automatically when the scheduled duration expires.
          </div>

          {/* Quick Demo Test Trigger */}
          <div className="mt-3 pt-3 border-t border-white/10 flex items-center justify-between">
            <span className="text-[11px] text-slate-400">Test Blocking Screen:</span>
            <button
              onClick={() => onSimulateAppLaunch('YouTube')}
              className="px-3 py-1.5 rounded-lg bg-rose-600/80 hover:bg-rose-500 text-[11px] font-medium text-white transition-all"
            >
              Simulate Opening Blocked App
            </button>
          </div>
        </div>
      ) : (
        <div className="w-full p-3.5 rounded-2xl bg-white/[0.03] border border-white/10 mb-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400">
              <Clock className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-medium text-white">{nextInfo.timeDisplay}</p>
              <p className="text-[10px] text-slate-400">Recurring schedules active</p>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 1: MANUAL TEMPORARY SESSIONS */}
      <div className="mb-6">
        <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
          <Clock className="w-3.5 h-3.5 text-indigo-400" />
          <span>Manual Temporary Focus Sessions</span>
        </h3>

        <div className="grid grid-cols-3 gap-2">
          {/* 2 Hours */}
          <button
            onClick={() => handleStartManual(120)}
            disabled={focusState.isActive}
            className="p-3 rounded-xl bg-white/5 hover:bg-white/10 disabled:opacity-40 border border-white/10 text-center transition-all group active:scale-95"
          >
            <span className="text-sm font-bold text-white group-hover:text-indigo-300">2 Hours</span>
            <p className="text-[10px] text-slate-400 mt-0.5">Quick deep block</p>
          </button>

          {/* 3 Hours */}
          <button
            onClick={() => handleStartManual(180)}
            disabled={focusState.isActive}
            className="p-3 rounded-xl bg-white/5 hover:bg-white/10 disabled:opacity-40 border border-white/10 text-center transition-all group active:scale-95"
          >
            <span className="text-sm font-bold text-white group-hover:text-indigo-300">3 Hours</span>
            <p className="text-[10px] text-slate-400 mt-0.5">Study marathon</p>
          </button>

          {/* Custom Duration */}
          <div className="p-2 rounded-xl bg-white/5 border border-white/10 flex flex-col justify-between">
            <div className="flex items-center gap-1">
              <input
                type="number"
                min="5"
                max="360"
                value={customMinutes}
                onChange={e => setCustomMinutes(e.target.value)}
                disabled={focusState.isActive}
                className="w-12 bg-black/40 border border-white/10 rounded px-1.5 py-0.5 text-xs text-white text-center font-mono outline-none"
              />
              <span className="text-[10px] text-slate-400">mins</span>
            </div>
            <button
              onClick={() => handleStartManual(Number(customMinutes) || 45)}
              disabled={focusState.isActive}
              className="w-full mt-1 py-1 rounded bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-[10px] font-medium text-white transition-colors"
            >
              Start Custom
            </button>
          </div>
        </div>
      </div>

      {/* SECTION 2: FOUR CONFIGURED RECURRING DAILY SCHEDULES */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2.5">
          <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5 text-indigo-400" />
            <span>Four Recurring Daily Schedules</span>
          </h3>
          <span className="text-[10px] text-slate-500 font-mono">Overnight supported</span>
        </div>

        <div className="space-y-2.5">
          {schedules.map(schedule => {
            const isCurrentlyActiveSchedule = focusState.isActive && focusState.scheduleId === schedule.id;

            return (
              <div
                key={schedule.id}
                className={`p-3 rounded-xl border transition-all ${
                  isCurrentlyActiveSchedule
                    ? 'bg-amber-950/20 border-amber-500/40'
                    : schedule.isEnabled
                    ? 'bg-white/[0.03] border-white/10'
                    : 'bg-white/[0.01] border-white/5 opacity-60'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-xs font-semibold text-white">{schedule.name}</h4>
                      {schedule.startTime > schedule.endTime && (
                        <span className="text-[9px] px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300 font-mono">
                          Crosses Midnight
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] font-mono text-indigo-300 mt-0.5">
                      {schedule.startTime} — {schedule.endTime}
                    </p>
                  </div>

                  {/* Toggle Button */}
                  <button
                    onClick={() => handleToggleSchedule(schedule.id)}
                    className={`px-3 py-1 rounded-full text-[10px] font-semibold tracking-wide transition-all ${
                      schedule.isEnabled
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : 'bg-white/5 text-slate-400 border border-white/5 hover:text-white'
                    }`}
                  >
                    {schedule.isEnabled ? 'ENABLED' : 'DISABLED'}
                  </button>
                </div>

                {/* Blocked Apps list preview */}
                <div className="mt-2 pt-2 border-t border-white/[0.04] flex flex-wrap gap-1 text-[10px] text-slate-400">
                  <span className="text-slate-500 mr-1">Blocked:</span>
                  {schedule.blockedApps.map(app => (
                    <span key={app} className="px-1.5 py-0.2 rounded bg-black/30 border border-white/5 text-slate-300">
                      {app}
                    </span>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* SECTION 3: HONEST PLATFORM LIMITATION DISCLOSURE */}
      <div className="mt-auto p-3.5 rounded-xl bg-slate-900/60 border border-white/10 text-[11px] text-slate-400 leading-relaxed">
        <div className="flex items-center gap-1.5 text-slate-300 font-medium mb-1">
          <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
          <span>Android Security & Architecture Disclosure</span>
        </div>
        A normal third-party Android launcher cannot guarantee that a user cannot force-stop or bypass blocking through system safe-mode or ADB. NTC Launcher uses Android’s official AccessibilityService and AlarmManager for the strongest policy-compliant enforcement. 100% tamper-proof locking requires managed enterprise Device-Owner (MDM) status.
      </div>
    </div>
  );
};
