import React, { useState } from 'react';
import { Check, X, Clock, History, Edit3, MessageSquare } from 'lucide-react';
import { GoalItem, GoalStatus } from '../types/launcher';
import { PasswordAuthModal } from './PasswordAuthModal';

interface GoalCardsSectionProps {
  goals: GoalItem[];
  onUpdateGoalTitle: (goalId: string, newTitle: string) => void;
  onUpdateGoalStatus: (goalId: string, status: GoalStatus, excuseReason?: string) => void;
  onOpenHistory: () => void;
  fontFamily?: string;
}

export const GoalCardsSection: React.FC<GoalCardsSectionProps> = ({
  goals,
  onUpdateGoalTitle,
  onUpdateGoalStatus,
  onOpenHistory,
  fontFamily,
}) => {
  const [editingGoalId, setEditingGoalId] = useState<string | null>(null);
  const [editTitleInput, setEditTitleInput] = useState('');
  
  const [authenticatingGoalId, setAuthenticatingGoalId] = useState<string | null>(null);
  const [excusePromptGoalId, setExcusePromptGoalId] = useState<string | null>(null);
  const [excuseInput, setExcuseInput] = useState('');

  // Exactly 6 cards (pad or slice to guarantee 6)
  const displayGoals = Array.from({ length: 6 }, (_, index) => {
    return goals.find(g => g.slotIndex === index) || {
      id: `virtual_${index}`,
      slotIndex: index,
      title: '',
      status: 'pending' as const,
    };
  });

  const handleStartEdit = (goal: GoalItem) => {
    setEditingGoalId(goal.id);
    setEditTitleInput(goal.title);
  };

  const handleSaveEdit = (goalId: string) => {
    onUpdateGoalTitle(goalId, editTitleInput.trim());
    setEditingGoalId(null);
  };

  const handleMarkDoingClick = (goal: GoalItem) => {
    // Requires password / PIN verification
    setAuthenticatingGoalId(goal.id);
  };

  const handleAuthSuccess = () => {
    if (authenticatingGoalId) {
      onUpdateGoalStatus(authenticatingGoalId, 'doing');
      setAuthenticatingGoalId(null);
    }
  };

  const handleMarkExcuseClick = (goal: GoalItem) => {
    setExcusePromptGoalId(goal.id);
    setExcuseInput(goal.excuseReason || '');
  };

  const handleSaveExcuse = (goalId: string) => {
    onUpdateGoalStatus(goalId, 'excuse', excuseInput.trim() || undefined);
    setExcusePromptGoalId(null);
  };

  const handleResetPending = (goalId: string) => {
    onUpdateGoalStatus(goalId, 'pending');
  };

  return (
    <div className="w-full flex flex-col items-center">
      {/* Small, unobtrusive History button directly above the six cards */}
      {/* Prompt: Do not display the date, weekday, or any additional header above these six cards. */}
      {/* Prompt: Add a small, unobtrusive History button directly above the six To-do cards. Do not create a large History header. */}
      <div className="w-full flex justify-end items-center mb-1.5 px-0.5">
        <button
          onClick={onOpenHistory}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/5 hover:bg-white/10 active:bg-white/15 text-slate-300 hover:text-white text-[11px] font-medium tracking-wide transition-all border border-white/5"
          title="Open Daily, Weekly & Monthly History"
        >
          <History className="w-3 h-3 text-indigo-400" />
          <span>History</span>
        </button>
      </div>

      {/* Fixed 2-column by 3-row layout */}
      <div className="w-full grid grid-cols-2 gap-2" style={{ fontFamily }}>
        {displayGoals.map((goal, idx) => {
          const isDoing = goal.status === 'doing';
          const isExcuse = goal.status === 'excuse';
          const isPending = goal.status === 'pending';
          const hasTitle = Boolean(goal.title && goal.title.trim().length > 0);

          return (
            <div
              key={goal.id || idx}
              className={`relative flex flex-col justify-between p-2.5 rounded-xl border transition-all duration-200 min-h-[72px] sm:min-h-[78px] ${
                isDoing
                  ? 'bg-emerald-950/25 border-emerald-500/30 text-emerald-100 shadow-sm shadow-emerald-950/50'
                  : isExcuse
                  ? 'bg-amber-950/25 border-amber-500/30 text-amber-100 shadow-sm shadow-amber-950/50'
                  : 'bg-white/[0.04] border-white/10 text-slate-200 hover:border-white/20'
              }`}
            >
              {/* Header: Slot Index & Status Marker */}
              <div className="flex items-center justify-between text-[10px] tracking-wider mb-1">
                <span className="font-mono text-slate-400 opacity-70">
                  #{idx + 1}
                </span>

                <div className="flex items-center gap-1">
                  {isDoing && (
                    <span className="flex items-center gap-0.5 text-emerald-400 font-semibold text-[10px]">
                      <Check className="w-3 h-3 stroke-[2.5]" />
                      <span>DOING</span>
                    </span>
                  )}
                  {isExcuse && (
                    <span className="flex items-center gap-0.5 text-amber-400 font-semibold text-[10px]">
                      <X className="w-3 h-3 stroke-[2.5]" />
                      <span>EXCUSE</span>
                    </span>
                  )}
                  {isPending && (
                    <span className="text-slate-400 text-[10px] tracking-tight">
                      PENDING
                    </span>
                  )}
                </div>
              </div>

              {/* Goal Title / Input */}
              {editingGoalId === goal.id ? (
                <div className="my-1">
                  <input
                    type="text"
                    value={editTitleInput}
                    onChange={e => setEditTitleInput(e.target.value)}
                    onKeyDown={e => {
                      if (e.key === 'Enter') handleSaveEdit(goal.id);
                      if (e.key === 'Escape') setEditingGoalId(null);
                    }}
                    autoFocus
                    placeholder="Enter daily goal..."
                    className="w-full bg-black/40 border border-indigo-400/50 rounded-lg px-2 py-1 text-xs text-white placeholder-slate-500 outline-none focus:ring-1 focus:ring-indigo-400"
                  />
                  <div className="flex justify-end gap-1.5 mt-1">
                    <button
                      onClick={() => setEditingGoalId(null)}
                      className="text-[10px] text-slate-400 hover:text-white px-1.5 py-0.5"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => handleSaveEdit(goal.id)}
                      className="text-[10px] text-indigo-300 hover:text-white font-medium bg-indigo-500/20 px-2 py-0.5 rounded"
                    >
                      Save
                    </button>
                  </div>
                </div>
              ) : (
                <div
                  onClick={() => handleStartEdit(goal)}
                  className="flex-1 cursor-pointer group flex flex-col justify-center my-0.5"
                  title="Click to edit goal title"
                >
                  <p
                    className={`text-xs leading-snug line-clamp-2 transition-colors ${
                      hasTitle
                        ? isDoing
                          ? 'text-emerald-100 font-medium'
                          : isExcuse
                          ? 'text-amber-100 line-through opacity-80'
                          : 'text-slate-100 group-hover:text-white'
                        : 'text-slate-500 italic'
                    }`}
                  >
                    {hasTitle ? goal.title : '+ Tap to set goal'}
                  </p>
                  {isExcuse && goal.excuseReason && (
                    <p className="text-[9px] text-amber-400/80 truncate mt-0.5 italic">
                      Reason: {goal.excuseReason}
                    </p>
                  )}
                  {isDoing && goal.completedAt && (
                    <p className="text-[9px] text-emerald-400/75 truncate mt-0.5 font-mono">
                      Completed at {new Date(goal.completedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  )}
                </div>
              )}

              {/* Status Action Controls */}
              <div className="flex items-center justify-between pt-1 border-t border-white/[0.06] mt-1 text-[10px]">
                <button
                  onClick={() => handleStartEdit(goal)}
                  className="text-slate-400 hover:text-slate-200 transition-colors p-0.5"
                  title="Edit title"
                >
                  <Edit3 className="w-2.5 h-2.5" />
                </button>

                <div className="flex items-center gap-1">
                  {/* Mark as Doing (Requires Password/PIN) */}
                  <button
                    onClick={() => handleMarkDoingClick(goal)}
                    disabled={isDoing}
                    className={`flex items-center gap-0.5 px-2 py-0.5 rounded transition-all ${
                      isDoing
                        ? 'bg-emerald-500/30 text-emerald-200 cursor-default'
                        : 'bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 hover:text-emerald-200'
                    }`}
                    title="Mark Doing (PIN protected)"
                  >
                    <Check className="w-2.5 h-2.5 stroke-[2.5]" />
                    <span className="font-medium text-[9px]">Doing</span>
                  </button>

                  {/* Mark as Excuse */}
                  <button
                    onClick={() => handleMarkExcuseClick(goal)}
                    disabled={isExcuse}
                    className={`flex items-center gap-0.5 px-2 py-0.5 rounded transition-all ${
                      isExcuse
                        ? 'bg-amber-500/30 text-amber-200 cursor-default'
                        : 'bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 hover:text-amber-200'
                    }`}
                    title="Mark Excuse (with reason)"
                  >
                    <X className="w-2.5 h-2.5 stroke-[2.5]" />
                    <span className="font-medium text-[9px]">Excuse</span>
                  </button>

                  {!isPending && (
                    <button
                      onClick={() => handleResetPending(goal.id)}
                      className="text-[9px] text-slate-500 hover:text-slate-300 p-0.5"
                      title="Reset to Pending"
                    >
                      Reset
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Password/PIN Authentication Modal */}
      <PasswordAuthModal
        isOpen={Boolean(authenticatingGoalId)}
        title="Verify PIN to Complete Goal"
        subtitle="Enter your configured Goal Completion PIN to record this as Doing."
        onSuccess={handleAuthSuccess}
        onCancel={() => setAuthenticatingGoalId(null)}
      />

      {/* Optional Excuse Reason Modal */}
      {excusePromptGoalId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="w-full max-w-xs rounded-2xl bg-[#14161f] border border-white/10 p-5 shadow-2xl text-slate-100">
            <div className="flex items-center gap-2 mb-3">
              <div className="p-1.5 rounded-lg bg-amber-500/10 text-amber-400">
                <MessageSquare className="w-4 h-4" />
              </div>
              <h3 className="text-sm font-semibold text-white">Record Excuse Reason</h3>
            </div>
            <p className="text-xs text-slate-300 mb-3">
              Provide an optional reason why this goal could not be completed today:
            </p>
            <input
              type="text"
              value={excuseInput}
              onChange={e => setExcuseInput(e.target.value)}
              placeholder="e.g. Health, urgent travel, priority shift..."
              className="w-full bg-black/40 border border-white/15 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 outline-none focus:border-amber-400 mb-4"
              autoFocus
            />
            <div className="flex gap-2">
              <button
                onClick={() => setExcusePromptGoalId(null)}
                className="flex-1 py-2 rounded-xl border border-white/10 text-xs text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={() => handleSaveExcuse(excusePromptGoalId)}
                className="flex-1 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-xs font-medium text-white"
              >
                Save Reason
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
