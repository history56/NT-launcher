import React, { useState, useMemo } from 'react';
import { Search, ChevronRight, X } from 'lucide-react';
import { SYSTEM_INSTALLED_APPS } from '../utils/installedApps';

interface AllAppsScreenProps {
  onBackToHome: () => void;
  onLaunchApp: (appName: string, packageName: string) => void;
  fontFamily?: string;
}

export const AllAppsScreen: React.FC<AllAppsScreenProps> = ({
  onBackToHome,
  onLaunchApp,
  fontFamily,
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  // Sorted alphabetically by name
  const sortedApps = useMemo(() => {
    return [...SYSTEM_INSTALLED_APPS].sort((a, b) => a.name.localeCompare(b.name));
  }, []);

  // Filtered by search query
  const filteredApps = useMemo(() => {
    if (!searchQuery.trim()) return sortedApps;
    const query = searchQuery.toLowerCase();
    return sortedApps.filter(app =>
      app.name.toLowerCase().includes(query) ||
      app.packageName.toLowerCase().includes(query)
    );
  }, [sortedApps, searchQuery]);

  return (
    <div
      className="w-full h-full flex flex-col p-4 sm:p-6 overflow-hidden text-slate-100 animate-in fade-in slide-in-from-left duration-200"
      style={{ fontFamily }}
    >
      {/* Top Header with Back to Home button */}
      <div className="flex items-center justify-between pb-3 mb-3 border-b border-white/10">
        <h2 className="text-sm font-semibold tracking-wide text-white uppercase">All Applications</h2>
        <button
          onClick={onBackToHome}
          className="flex items-center gap-1 text-xs text-slate-400 hover:text-white transition-colors py-1 px-2.5 rounded-lg hover:bg-white/5"
        >
          <span>Home</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {/* Search Input at Top */}
      <div className="relative mb-4">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          placeholder="Search installed apps..."
          className="w-full bg-white/[0.04] border border-white/10 rounded-2xl pl-10 pr-9 py-2.5 text-xs text-white placeholder-slate-500 outline-none focus:border-indigo-400 focus:ring-1 focus:ring-indigo-400/50 transition-all"
          autoFocus
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-0.5"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Vertical list of installed applications: Names only, NO app icons in the list (Pure Minimalist Typography) */}
      <div className="flex-1 overflow-y-auto pr-1 space-y-0.5 divide-y divide-white/[0.03]">
        {filteredApps.length === 0 ? (
          <div className="py-12 text-center text-slate-500">
            <p className="text-xs">No matching applications found</p>
            <p className="text-[10px] mt-1 text-slate-600">Try searching with a different term</p>
          </div>
        ) : (
          filteredApps.map(app => (
            <button
              key={app.id}
              onClick={() => onLaunchApp(app.name, app.packageName)}
              className="w-full flex items-center justify-between py-2.5 px-3 rounded-lg hover:bg-white/[0.05] active:bg-white/10 transition-colors text-left group"
            >
              <div className="flex items-baseline gap-2">
                <span className="text-sm font-normal text-slate-200 group-hover:text-white group-hover:translate-x-1 duration-150 tracking-wide">
                  {app.name}
                </span>
              </div>
              <span className="text-[10px] font-mono text-slate-500 opacity-0 group-hover:opacity-100 transition-opacity">
                {app.packageName}
              </span>
            </button>
          ))
        )}
      </div>

      <div className="pt-3 border-t border-white/5 text-[10px] text-slate-500 font-mono text-center">
        {filteredApps.length} installed apps • Minimalist text list
      </div>
    </div>
  );
};
