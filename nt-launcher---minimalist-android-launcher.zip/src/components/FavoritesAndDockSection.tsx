import React, { useState } from 'react';
import { Phone, Camera, GraduationCap, AlertCircle, ExternalLink, X } from 'lucide-react';
import { DEFAULT_FAVORITES, DOCK_APPS } from '../utils/themesAndFonts';

interface FavoritesAndDockSectionProps {
  onLaunchApp: (appName: string, packageName: string) => void;
  fontFamily?: string;
  onOpenSettings: () => void;
}

export const FavoritesAndDockSection: React.FC<FavoritesAndDockSectionProps> = ({
  onLaunchApp,
  fontFamily,
  onOpenSettings,
}) => {
  const [khanGsFallbackOpen, setKhanGsFallbackOpen] = useState(false);

  const handleDockClick = (app: typeof DOCK_APPS[0]) => {
    if (app.id === 'dock-phone') {
      onLaunchApp(app.name, app.packageName);
    } else if (app.id === 'dock-camera') {
      onLaunchApp(app.name, app.packageName);
    } else if (app.id === 'dock-kgs') {
      // Khan Global Studies resolution with graceful fallback
      // On real Android, it checks PackageManager.getLaunchIntentForPackage("xyz.penpencil.khanglobalstudies")
      // If null, opens Play Store or Fallback dialog
      onLaunchApp(app.name, app.packageName);
    }
  };

  return (
    <div className="w-full mt-auto pt-2 pb-1" style={{ fontFamily }}>
      {/* Lower area with Favorites list in the lower-left area separated with a vertical divider */}
      <div className="flex items-end justify-between px-2 mb-3">
        {/* Lower-left Favorites Section: 5-6 user-selected favorite apps shown as a vertical text-only list */}
        <div className="flex items-stretch gap-3">
          <div className="flex flex-col gap-1 select-none">
            {DEFAULT_FAVORITES.map(fav => (
              <button
                key={fav.id}
                onClick={() => onLaunchApp(fav.name, fav.packageName)}
                className="text-left text-xs font-light text-slate-300 hover:text-white transition-colors py-0.5 tracking-wide hover:translate-x-1 duration-150"
              >
                {fav.name}
              </button>
            ))}
          </div>

          {/* Vertical Divider separating Favorites from the rest of the screen */}
          <div className="w-[1px] bg-white/15 my-0.5 self-stretch rounded-full" />
        </div>

        {/* Subtle quick launcher hint */}
        <div className="text-right text-[10px] text-slate-500 font-mono tracking-tight pb-1">
          <span>Swipe ◄ All Apps</span>
          <br />
          <span>Swipe ► Focus</span>
        </div>
      </div>

      {/* Dock at bottom containing: Phone, Camera, Khan Global Studies */}
      <div className="w-full flex items-center justify-around py-2 px-6 rounded-2xl bg-white/[0.04] border border-white/10 backdrop-blur-md shadow-lg">
        {/* Phone */}
        <button
          onClick={() => handleDockClick(DOCK_APPS[0])}
          className="flex flex-col items-center gap-1 group active:scale-95 transition-transform"
          title="Phone (com.google.android.dialer)"
        >
          <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/25 flex items-center justify-center text-emerald-300 group-hover:scale-105 transition-transform shadow-sm">
            <Phone className="w-4 h-4" />
          </div>
          <span className="text-[10px] text-slate-300 font-medium tracking-tight">Phone</span>
        </button>

        {/* Camera */}
        <button
          onClick={() => handleDockClick(DOCK_APPS[1])}
          className="flex flex-col items-center gap-1 group active:scale-95 transition-transform"
          title="Camera (com.android.camera)"
        >
          <div className="w-10 h-10 rounded-xl bg-sky-500/15 border border-sky-500/25 flex items-center justify-center text-sky-300 group-hover:scale-105 transition-transform shadow-sm">
            <Camera className="w-4 h-4" />
          </div>
          <span className="text-[10px] text-slate-300 font-medium tracking-tight">Camera</span>
        </button>

        {/* Khan Global Studies */}
        <button
          onClick={() => handleDockClick(DOCK_APPS[2])}
          className="flex flex-col items-center gap-1 group active:scale-95 transition-transform"
          title="Khan Global Studies (xyz.penpencil.khanglobalstudies)"
        >
          <div className="w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-500/25 flex items-center justify-center text-amber-300 group-hover:scale-105 transition-transform shadow-sm">
            <GraduationCap className="w-4 h-4" />
          </div>
          <span className="text-[10px] text-slate-300 font-medium tracking-tight">Khan GS</span>
        </button>
      </div>

      {/* Fallback Dialog for Khan Global Studies if needed */}
      {khanGsFallbackOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="w-full max-w-sm rounded-2xl bg-[#14161f] border border-white/10 p-5 shadow-2xl text-slate-100">
            <div className="flex items-center justify-between pb-2 border-b border-white/5">
              <div className="flex items-center gap-2 text-amber-400">
                <AlertCircle className="w-5 h-5" />
                <h3 className="text-sm font-semibold text-white">App Intent Resolution</h3>
              </div>
              <button
                onClick={() => setKhanGsFallbackOpen(false)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-xs text-slate-300 my-3 leading-relaxed">
              Package <code className="text-amber-300">xyz.penpencil.khanglobalstudies</code> is resolved on device.
              If not installed on your Vivo V21, NTC Launcher provides a direct download or web study portal fallback instead of crashing.
            </p>
            <div className="flex gap-2">
              <a
                href="https://play.google.com/store/apps/details?id=xyz.penpencil.khanglobalstudies"
                target="_blank"
                rel="noreferrer"
                className="flex-1 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-xs font-medium text-white flex items-center justify-center gap-1.5"
              >
                <span>Play Store</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
              <button
                onClick={() => setKhanGsFallbackOpen(false)}
                className="px-4 py-2 rounded-xl border border-white/10 text-xs text-slate-400 hover:text-white"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
