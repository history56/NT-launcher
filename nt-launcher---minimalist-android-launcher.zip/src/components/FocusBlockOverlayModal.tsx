import React, { useState, useEffect } from 'react';
import { ShieldAlert, Timer, AlertOctagon, X, Clock, Check } from 'lucide-react';
import { FocusSessionState } from '../types/launcher';
import { requestEmergencyAccess } from '../utils/focusManager';

interface FocusBlockOverlayModalProps {
  isOpen: boolean;
  blockedAppName: string;
  focusState: FocusSessionState;
  onClose: () => void;
  onEmergencyGranted: (updatedState: FocusSessionState) => void;
}

export const FocusBlockOverlayModal: React.FC<FocusBlockOverlayModalProps> = ({
  isOpen,
  blockedAppName,
  focusState,
  onClose,
  onEmergencyGranted,
}) => {
  const [countdownSeconds, setCountdownSeconds] = useState<number | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Check if active 60s emergency access is currently running
  useEffect(() => {
    if (!isOpen) return;

    const checkEmergency = () => {
      if (focusState.emergencyAccessExpiresAt) {
        const remainingMs = focusState.emergencyAccessExpiresAt - Date.now();
        if (remainingMs > 0) {
          setCountdownSeconds(Math.ceil(remainingMs / 1000));
        } else {
          setCountdownSeconds(null);
        }
      } else {
        setCountdownSeconds(null);
      }
    };

    checkEmergency();
    const interval = setInterval(checkEmergency, 1000);
    return () => clearInterval(interval);
  }, [isOpen, focusState]);

  if (!isOpen) return null;

  const handleEmergencyClick = () => {
    setErrorMessage(null);
    const result = requestEmergencyAccess(focusState);
    if (result.success) {
      onEmergencyGranted(result.updatedState);
    } else {
      setErrorMessage(result.message);
    }
  };

  return (
    <div className="fixed inset-0 z-70 flex items-center justify-center bg-black/90 backdrop-blur-lg p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-sm rounded-3xl bg-[#120e18] border border-rose-500/30 p-6 shadow-2xl text-center text-slate-100 flex flex-col items-center">
        {/* Blocking Shield Icon */}
        <div className="w-16 h-16 rounded-2xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400 mb-4 animate-pulse shadow-lg shadow-rose-950/50">
          <ShieldAlert className="w-8 h-8" />
        </div>

        {/* Required Prompt Text:
            “Your Focus Mode Is On
            This app is blocked during your focus session.” */}
        <h2 className="text-xl font-bold tracking-tight text-white mb-1">
          Your Focus Mode Is On
        </h2>
        <p className="text-xs text-rose-300 font-medium mb-3">
          This app is blocked during your focus session.
        </p>

        <div className="w-full p-3 rounded-xl bg-white/[0.03] border border-white/5 my-2">
          <p className="text-xs text-slate-300">
            Target App: <strong className="text-white font-semibold">{blockedAppName}</strong>
          </p>
          <p className="text-[11px] text-slate-400 mt-1">
            Session: <span className="text-indigo-300">{focusState.name || 'Focus Mode Active'}</span>
          </p>
        </div>

        {/* Emergency Access Countdown Display if Active */}
        {countdownSeconds !== null && countdownSeconds > 0 ? (
          <div className="w-full my-3 p-3 rounded-2xl bg-amber-500/15 border border-amber-500/30">
            <div className="flex items-center justify-center gap-2 text-amber-300 font-mono text-lg font-bold">
              <Timer className="w-5 h-5 animate-spin" />
              <span>{countdownSeconds}s REMAINING</span>
            </div>
            <p className="text-[10px] text-amber-200/90 mt-1">
              Temporary 60-second allowance in progress. Blocking reapplies automatically.
            </p>
          </div>
        ) : (
          <div className="w-full my-3">
            <button
              onClick={handleEmergencyClick}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white font-medium text-xs tracking-wide transition-all shadow-md active:scale-95 flex items-center justify-center gap-2"
            >
              <Timer className="w-4 h-4" />
              <span>Use for 60 seconds</span>
            </button>
            <p className="text-[10px] text-slate-500 mt-1.5">
              Strict limit: Max 1 allowance per rolling hour. Focus session stays active.
            </p>
          </div>
        )}

        {errorMessage && (
          <div className="p-2.5 rounded-xl bg-rose-500/15 border border-rose-500/25 text-rose-300 text-[11px] my-2 text-left">
            {errorMessage}
          </div>
        )}

        {/* Return to Launcher Button */}
        <button
          onClick={onClose}
          className="mt-4 w-full py-2.5 rounded-xl border border-white/10 hover:bg-white/5 text-xs text-slate-300 hover:text-white transition-colors"
        >
          Return to Home Screen
        </button>

        {/* Platform Limitation Disclaimer */}
        <p className="text-[9px] text-slate-600 mt-4 leading-tight">
          Third-party launcher restriction: Policy-compliant AccessibilityService blocking. Absolute tamper-proof locking requires Android Device Owner mode.
        </p>
      </div>
    </div>
  );
};
