import { UsageStatItem } from '../types/launcher';

const USAGE_PERMISSION_KEY = 'ntc_usage_stats_permission_granted_v1';
const USAGE_STATS_CACHE_KEY = 'ntc_usage_stats_cache_v1';

export function isUsageAccessGranted(): boolean {
  return localStorage.getItem(USAGE_PERMISSION_KEY) === 'true';
}

export function setUsageAccessGranted(granted: boolean): void {
  localStorage.setItem(USAGE_PERMISSION_KEY, granted ? 'true' : 'false');
}

// Initial realistic device usage statistics for top apps
export const INITIAL_USAGE_DATA: UsageStatItem[] = [
  {
    packageName: 'xyz.penpencil.khanglobalstudies',
    appName: 'Khan GS',
    usageMinutesToday: 135, // 2h 15m
    usageMinutesWeek: 840,  // 14h 00m
    lastTimeUsed: '25m ago',
  },
  {
    packageName: 'com.google.android.youtube',
    appName: 'YouTube',
    usageMinutesToday: 95,  // 1h 35m
    usageMinutesWeek: 620,
    lastTimeUsed: '1h ago',
  },
  {
    packageName: 'com.android.chrome',
    appName: 'Chrome',
    usageMinutesToday: 68,  // 1h 08m
    usageMinutesWeek: 450,
    lastTimeUsed: '12m ago',
  },
  {
    packageName: 'com.whatsapp',
    appName: 'WhatsApp',
    usageMinutesToday: 42,  // 42m
    usageMinutesWeek: 310,
    lastTimeUsed: '5m ago',
  },
  {
    packageName: 'com.google.android.apps.messaging',
    appName: 'Notes / Docs',
    usageMinutesToday: 35,  // 35m
    usageMinutesWeek: 210,
    lastTimeUsed: '2h ago',
  },
  {
    packageName: 'com.google.android.dialer',
    appName: 'Phone',
    usageMinutesToday: 24,  // 24m
    usageMinutesWeek: 180,
    lastTimeUsed: '40m ago',
  },
];

export function getUsageStats(): UsageStatItem[] {
  try {
    const raw = localStorage.getItem(USAGE_STATS_CACHE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to get usage stats', e);
  }
  // Store default
  localStorage.setItem(USAGE_STATS_CACHE_KEY, JSON.stringify(INITIAL_USAGE_DATA));
  return INITIAL_USAGE_DATA;
}

export function refreshUsageStats(): UsageStatItem[] {
  // Simulate updated usage stats
  const current = getUsageStats();
  const updated = current.map(item => ({
    ...item,
    usageMinutesToday: Math.min(360, item.usageMinutesToday + Math.floor(Math.random() * 5)),
  }));
  localStorage.setItem(USAGE_STATS_CACHE_KEY, JSON.stringify(updated));
  return updated;
}
