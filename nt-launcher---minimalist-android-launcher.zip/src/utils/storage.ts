import { DailySession, GoalItem, HistoryDailyRecord } from '../types/launcher';

const CURRENT_SESSION_KEY = 'ntc_launcher_current_session_v1';
const HISTORY_SESSIONS_KEY = 'ntc_launcher_history_sessions_v1';
const FIRST_USE_DATE_KEY = 'ntc_launcher_first_use_date_v1';

// Format Date to YYYY-MM-DD local string
export function getLocalDateString(d: Date = new Date()): string {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

// Generate empty 6 goal cards
export function createEmptyGoals(): GoalItem[] {
  return Array.from({ length: 6 }, (_, index) => ({
    id: `goal_${Date.now()}_slot_${index}_${Math.random().toString(36).substring(2, 7)}`,
    slotIndex: index,
    title: '',
    status: 'pending' as const,
  }));
}

// Pre-seeded history generator for demonstration and testing
function generateSeedHistory(startDateStr: string, daysCount = 14): DailySession[] {
  const sessions: DailySession[] = [];
  const start = new Date(startDateStr);

  const sampleGoals = [
    ['Morning Deep Focus (2h)', 'Read 20 pages Book', 'Workout / Pushups 50x', 'Review DSA / Coding Problem', 'Khan Global Studies Lecture', 'No Sugar & Hydrate 3L'],
    ['Wake up 6:00 AM', 'Cold Shower & Meditate', 'Khan GS Current Affairs', 'Write 500 words Journal', 'Practice Math Problems', 'Walk 8,000 Steps'],
    ['Revise History Notes', 'Khan GS Geography Class', 'Clean Work Desk', 'Code NTC Launcher module', 'Evening Run 3km', 'Sleep by 11:00 PM'],
    ['Draft Project Architecture', 'Read Economic Survey', 'Language Practice 30m', 'Fix App Blocking Edge-case', 'Prepare Daily Summary', 'Digital Detox after 9 PM']
  ];

  for (let i = daysCount; i >= 1; i--) {
    const d = new Date(start);
    d.setDate(d.getDate() - i);
    const dateStr = getLocalDateString(d);

    const goalTitles = sampleGoals[i % sampleGoals.length];
    const goals: GoalItem[] = [];

    // Realistic distribution of Doing, Excuse, Pending
    for (let slot = 0; slot < 6; slot++) {
      const title = goalTitles[slot] || `Goal ${slot + 1}`;
      let status: 'doing' | 'excuse' | 'pending' = 'doing';
      let completedAt: string | undefined = undefined;
      let excuseReason: string | undefined = undefined;

      const rand = (i * 7 + slot * 13) % 10;
      if (rand >= 4) {
        status = 'doing';
        const compDate = new Date(d);
        compDate.setHours(9 + slot * 2, 15, 0);
        completedAt = compDate.toISOString();
      } else if (rand >= 2) {
        status = 'excuse';
        excuseReason = slot % 2 === 0 ? 'Urgent family task came up' : 'Low energy / rescheduled';
      } else {
        status = 'pending';
      }

      goals.push({
        id: `seed_${dateStr}_slot_${slot}`,
        slotIndex: slot,
        title,
        status,
        completedAt,
        excuseReason,
      });
    }

    sessions.push({
      date: dateStr,
      goals,
      isClosed: true,
      createdAt: new Date(d.setHours(6, 0, 0)).toISOString(),
      updatedAt: new Date(d.setHours(23, 59, 0)).toISOString(),
    });
  }

  return sessions;
}

// Load all historical sessions
export function loadHistorySessions(): DailySession[] {
  try {
    const raw = localStorage.getItem(HISTORY_SESSIONS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (e) {
    console.error('Error loading history sessions', e);
  }

  // If first time or empty, seed past 12 days
  const today = getLocalDateString();
  const seeded = generateSeedHistory(today, 12);
  saveHistorySessions(seeded);
  if (!localStorage.getItem(FIRST_USE_DATE_KEY) && seeded.length > 0) {
    localStorage.setItem(FIRST_USE_DATE_KEY, seeded[0].date);
  }
  return seeded;
}

// Save historical sessions
export function saveHistorySessions(sessions: DailySession[]): void {
  try {
    localStorage.setItem(HISTORY_SESSIONS_KEY, JSON.stringify(sessions));
  } catch (e) {
    console.error('Error saving history sessions', e);
  }
}

// Load or reconcile current daily session
export function loadOrReconcileCurrentSession(overrideDate?: string): DailySession {
  const currentDate = overrideDate || getLocalDateString();
  
  if (!localStorage.getItem(FIRST_USE_DATE_KEY)) {
    localStorage.setItem(FIRST_USE_DATE_KEY, currentDate);
  }

  let storedSession: DailySession | null = null;
  try {
    const raw = localStorage.getItem(CURRENT_SESSION_KEY);
    if (raw) {
      storedSession = JSON.parse(raw);
    }
  } catch (e) {
    console.error('Error parsing current session', e);
  }

  // Same day session exists and has 6 slots
  if (storedSession && storedSession.date === currentDate) {
    if (storedSession.goals.length !== 6) {
      // Ensure exactly 6 cards
      while (storedSession.goals.length < 6) {
        storedSession.goals.push({
          id: `goal_fix_${Date.now()}_${storedSession.goals.length}`,
          slotIndex: storedSession.goals.length,
          title: '',
          status: 'pending',
        });
      }
      storedSession.goals = storedSession.goals.slice(0, 6);
    }
    return storedSession;
  }

  // Date changed (Midnight rollover or first run or simulated date shift)
  if (storedSession && storedSession.date !== currentDate) {
    // Archive previous day's session into permanent history
    const finalizedPreviousSession: DailySession = {
      ...storedSession,
      isClosed: true,
      updatedAt: new Date().toISOString(),
      // Any goal still pending at midnight remains recorded as pending (Pending / Not Recorded)
      goals: storedSession.goals.map(g => ({
        ...g,
        status: g.status === 'doing' ? 'doing' : g.status === 'excuse' ? 'excuse' : 'pending',
      })),
    };

    const history = loadHistorySessions();
    // Avoid duplicate archive for same date
    const filteredHistory = history.filter(s => s.date !== finalizedPreviousSession.date);
    filteredHistory.push(finalizedPreviousSession);
    // Sort chronologically
    filteredHistory.sort((a, b) => a.date.localeCompare(b.date));
    saveHistorySessions(filteredHistory);
  }

  // Initialize new daily session for currentDate with 6 fresh cards
  const newSession: DailySession = {
    date: currentDate,
    goals: createEmptyGoals(),
    isClosed: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  saveCurrentSession(newSession);
  return newSession;
}

// Save active session
export function saveCurrentSession(session: DailySession): void {
  try {
    localStorage.setItem(CURRENT_SESSION_KEY, JSON.stringify(session));
  } catch (e) {
    console.error('Error saving current session', e);
  }
}

// Calculate percentages for a set of 6 goals
export function calculateDailyMetrics(goals: GoalItem[], isProvisional = false): {
  doingCount: number;
  excuseCount: number;
  pendingCount: number;
  doingPercent: number;
  excusePercent: number;
  pendingPercent: number;
  isProvisional: boolean;
} {
  const doingCount = goals.filter(g => g.status === 'doing').length;
  const excuseCount = goals.filter(g => g.status === 'excuse').length;
  const pendingCount = goals.filter(g => g.status === 'pending').length;

  // Exact whole-number percentage rules:
  // slot count is strictly 6
  const doingPercent = Math.round((doingCount / 6) * 100);
  const excusePercent = Math.round((excuseCount / 6) * 100);
  const pendingPercent = Math.round((pendingCount / 6) * 100);

  return {
    doingCount,
    excuseCount,
    pendingCount,
    doingPercent,
    excusePercent,
    pendingPercent,
    isProvisional,
  };
}

// Aggregate records into daily history list
export function getFullDailyHistoryRecords(): HistoryDailyRecord[] {
  const history = loadHistorySessions();
  const current = loadOrReconcileCurrentSession();

  const records: HistoryDailyRecord[] = [];

  // Add historical sessions (closed)
  for (const s of history) {
    if (s.date === current.date) continue; // skip if today
    const metrics = calculateDailyMetrics(s.goals, false);
    records.push({
      date: s.date,
      goals: s.goals,
      ...metrics,
    });
  }

  // Add current today's session (provisional)
  const currentMetrics = calculateDailyMetrics(current.goals, true);
  records.push({
    date: current.date,
    goals: current.goals,
    ...currentMetrics,
  });

  // Sort descending by date (most recent first)
  records.sort((a, b) => b.date.localeCompare(a.date));
  return records;
}

// Reset permanent history (Requires explicit authentication)
export function resetAllHistory(): void {
  const today = getLocalDateString();
  localStorage.removeItem(HISTORY_SESSIONS_KEY);
  localStorage.setItem(FIRST_USE_DATE_KEY, today);
  // Also reset current goals to clean state
  const cleanSession: DailySession = {
    date: today,
    goals: createEmptyGoals(),
    isClosed: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  saveCurrentSession(cleanSession);
}

// Export history to JSON string
export function exportHistoryAsJson(): string {
  const records = getFullDailyHistoryRecords();
  return JSON.stringify({
    appName: 'NTC Launcher',
    exportDate: new Date().toISOString(),
    totalRecordedDays: records.length,
    sessions: records,
  }, null, 2);
}

// Export history to CSV string
export function exportHistoryAsCsv(): string {
  const records = getFullDailyHistoryRecords();
  const headers = [
    'Date',
    'Goal_1_Title', 'Goal_1_Status', 'Goal_1_Time',
    'Goal_2_Title', 'Goal_2_Status', 'Goal_2_Time',
    'Goal_3_Title', 'Goal_3_Status', 'Goal_3_Time',
    'Goal_4_Title', 'Goal_4_Status', 'Goal_4_Time',
    'Goal_5_Title', 'Goal_5_Status', 'Goal_5_Time',
    'Goal_6_Title', 'Goal_6_Status', 'Goal_6_Time',
    'Doing_Count', 'Excuse_Count', 'Pending_Count',
    'Doing_Percent', 'Excuse_Percent', 'Pending_Percent', 'Is_Provisional'
  ];

  const rows = records.map(r => {
    const goalCols: string[] = [];
    for (let i = 0; i < 6; i++) {
      const g = r.goals[i];
      if (g) {
        goalCols.push(
          `"${(g.title || '').replace(/"/g, '""')}"`,
          `"${g.status}"`,
          `"${g.completedAt || ''}"`
        );
      } else {
        goalCols.push('""', '"pending"', '""');
      }
    }

    return [
      `"${r.date}"`,
      ...goalCols,
      r.doingCount,
      r.excuseCount,
      r.pendingCount,
      `${r.doingPercent}%`,
      `${r.excusePercent}%`,
      `${r.pendingPercent}%`,
      r.isProvisional ? 'Yes' : 'No',
    ].join(',');
  });

  return [headers.join(','), ...rows].join('\n');
}
