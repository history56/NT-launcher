import { PinAuthConfig } from '../types/launcher';

const PIN_STORAGE_KEY = 'ntc_launcher_pin_auth_v1';

// Helper to convert ArrayBuffer to Hex string
function bufferToHex(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  return Array.from(bytes)
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}

// Generate cryptographically secure random salt
export function generateSalt(length = 16): string {
  const array = new Uint8Array(length);
  crypto.getRandomValues(array);
  return bufferToHex(array.buffer);
}

// Compute SHA-256 hash of (salt + pin)
export async function hashPin(pin: string, salt: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(`${salt}:${pin}:ntc_secure_pepper_2026`);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  return bufferToHex(hashBuffer);
}

// Verify input pin against stored salt and hash
export async function verifyPin(inputPin: string, salt: string, storedHash: string): Promise<boolean> {
  if (!inputPin || !salt || !storedHash) return false;
  const computed = await hashPin(inputPin, salt);
  return computed === storedHash;
}

// Load PIN auth configuration
export function loadPinAuthConfig(): PinAuthConfig {
  try {
    const raw = localStorage.getItem(PIN_STORAGE_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    console.error('Failed to load PIN auth config', e);
  }
  // Default: unconfigured
  return {
    salt: '',
    pinHash: '',
    isConfigured: false,
    requireEditLock: false,
  };
}

// Save PIN auth configuration
export function savePinAuthConfig(config: PinAuthConfig): void {
  try {
    localStorage.setItem(PIN_STORAGE_KEY, JSON.stringify(config));
  } catch (e) {
    console.error('Failed to save PIN auth config', e);
  }
}

// Setup a new PIN
export async function setupNewPin(pin: string, requireEditLock = false): Promise<PinAuthConfig> {
  const salt = generateSalt();
  const pinHash = await hashPin(pin, salt);
  const newConfig: PinAuthConfig = {
    salt,
    pinHash,
    isConfigured: true,
    requireEditLock,
  };
  savePinAuthConfig(newConfig);
  return newConfig;
}

// Reset PIN credentials without altering historical data
export function resetPinCredentials(): void {
  const resetConfig: PinAuthConfig = {
    salt: '',
    pinHash: '',
    isConfigured: false,
    requireEditLock: false,
  };
  savePinAuthConfig(resetConfig);
}
