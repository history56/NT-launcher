import { FocusSchedule, FocusSessionState, AppTimeCheckConfig } from '../types/launcher';

const FOCUS_SCHEDULES_KEY = 'ntc_focus_schedules_v1';
const FOCUS_STATE_KEY = 'ntc_focus_active_state_v1';
const APP_TIME_CHECK_KEY = 'ntc_app_time_check_v1';

export const DEFAULT_FOCUS_SCHEDULES: FocusSchedule[] = [
  {
    id: 'sched-morning-deepwork',
    name: 'Morning Deep Work',
    startTime: '08:00',
    endTime: '11:30',
    blockedApps: ['YouTube', 'Instagram', 'Chrome', 'Facebook', 'Twitter/X'],
    isEnabled: true,
  },
  {
    id: 'sched-afternoon-study',
    name: 'Afternoon Study Block',
    startTime: '14:00',
    endTime: '17:00',
    blockedApps: ['YouTube', 'Instagram', 'WhatsApp', 'Netflix', 'Reddit'],
    isEnabled: true,
  },
  {
    id: 'sched-evening-discipline',
    name: 'Evening Learning Block',
    startTime: '19:30',
    endTime: '22:00',
    blockedApps: ['Instagram', 'Facebook', 'YouTube', 'TikTok'],
    isEnabled: true,
  },
  {
    id: 'sched-overnight-detox',
    name: 'Overnight Sleep Detox',
    startTime: '23:00',
    endTime: '06:00', // crosses midnight!
    blockedApps: ['Chrome', 'YouTube', 'Instagram', 'WhatsApp', 'Facebook', 'Twitter/X', 'Reddit'],
    isEnabled: true,
  },
];

export const DEFAULT_TIME_CHECK_APPS = [
  'Google',
  'Chrome',
  'YouTube',
  'Instagram',
  'Facebook',
  'WhatsApp',
];

// Helper to determine if current time falls within startTime and endTime, handling midnight rollover
export function isCurrentTimeInSchedule(startTime: string, endTime: string, now: Date = new Date()): boolean {
  const [startH, startM] = startTime.split(':').map(Number);
  const [endH, endM] = endTime.split(':').map(Number);

  const currentMinutes = now.getHours() * 60 + now.getMinutes();
  const startMinutes = startH * 60 + startM;
  const endMinutes = endH * 60 + endM;

  if (startMinutes <= endMinutes) {
    // Standard daytime window, e.g., 08:00 to 12:00
    return currentMinutes >= startMinutes && currentMinutes < endMinutes;
  } else {
    // Overnight window crossing midnight, e.g., 23:00 to 06:00
    return currentMinutes >= startMinutes || currentMinutes < endMinutes;
  }
}

// Format minutes until next schedule starts
export function getNextScheduleInfo(schedules: FocusSchedule[], now: Date = new Date()): { nextSchedule: FocusSchedule | null; timeDisplay: string } {
  const enabled = schedules.filter(s => s.isEnabled);
  if (enabled.length === 0) return { nextSchedule: null, timeDisplay: 'No scheduled sessions enabled' };

  const currentMinutes = now.getHours() * 60 + now.getMinutes();

  let closestDiff = Infinity;
  let closestSchedule: FocusSchedule | null = null;

  for (const s of enabled) {
    const [h, m] = s.startTime.split(':').map(Number);
    const sMinutes = h * 60 + m;
    let diff = sMinutes - currentMinutes;
    if (diff <= 0) {
      diff += 24 * 60; // Next day
    }
    if (diff < closestDiff) {
      closestDiff = diff;
      closestSchedule = s;
    }
  }

  if (!closestSchedule) return { nextSchedule: null, timeDisplay: 'None' };

  const hours = Math.floor(closestDiff / 60);
  const mins = closestDiff % 60;
  const inText = hours > 0 ? `${hours}h ${mins}m` : `${mins}m`;

  return {
    nextSchedule: closestSchedule,
    timeDisplay: `Next: ${closestSchedule.name} (${closestSchedule.startTime}–${closestSchedule.endTime}) in ${inText}`,
  };
}

// Load schedules
export function loadFocusSchedules(): FocusSchedule[] {
  try {
    const raw = localStorage.getItem(FOCUS_SCHEDULES_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to load focus schedules', e);
  }
  saveFocusSchedules(DEFAULT_FOCUS_SCHEDULES);
  return DEFAULT_FOCUS_SCHEDULES;
}

// Save schedules
export function saveFocusSchedules(schedules: FocusSchedule[]): void {
  try {
    localStorage.setItem(FOCUS_SCHEDULES_KEY, JSON.stringify(schedules));
  } catch (e) {
    console.error('Failed to save focus schedules', e);
  }
}

// Load active focus session state
export function loadFocusState(): FocusSessionState {
  try {
    const raw = localStorage.getItem(FOCUS_STATE_KEY);
    if (raw) {
      const parsed: FocusSessionState = JSON.parse(raw);
      // Verify if manual session expired
      if (parsed.isActive && parsed.expiresAt && Date.now() >= parsed.expiresAt) {
        parsed.isActive = false;
        parsed.mode = 'none';
        saveFocusState(parsed);
      }
      return parsed;
    }
  } catch (e) {
    console.error('Failed to load focus state', e);
  }

  return {
    isActive: false,
    mode: 'none',
    blockedApps: [],
  };
}

// Save active focus state
export function saveFocusState(state: FocusSessionState): void {
  try {
    localStorage.setItem(FOCUS_STATE_KEY, JSON.stringify(state));
  } catch (e) {
    console.error('Failed to save focus state', e);
  }
}

// Check schedule status dynamically (called on tick or app resume)
export function evaluateFocusStatus(schedules: FocusSchedule[]): FocusSessionState {
  const currentState = loadFocusState();
  const now = new Date();

  // If a manual session is running and unexpired, it takes precedence
  if (currentState.isActive && currentState.mode === 'manual') {
    if (currentState.expiresAt && Date.now() < currentState.expiresAt) {
      return currentState;
    }
    // Manual session expired
    currentState.isActive = false;
    currentState.mode = 'none';
    saveFocusState(currentState);
  }

  // Check recurring schedules
  for (const schedule of schedules) {
    if (schedule.isEnabled && isCurrentTimeInSchedule(schedule.startTime, schedule.endTime, now)) {
      const updated: FocusSessionState = {
        ...currentState,
        isActive: true,
        mode: 'schedule',
        scheduleId: schedule.id,
        name: schedule.name,
        blockedApps: schedule.blockedApps,
      };
      saveFocusState(updated);
      return updated;
    }
  }

  // If was in schedule mode but current time is no longer in any schedule
  if (currentState.isActive && currentState.mode === 'schedule') {
    const updated: FocusSessionState = {
      ...currentState,
      isActive: false,
      mode: 'none',
      scheduleId: undefined,
      name: undefined,
    };
    saveFocusState(updated);
    return updated;
  }

  return currentState;
}

// Start manual Focus session (2h, 3h, or custom in minutes)
export function startManualFocusSession(durationMinutes: number, blockedApps: string[]): FocusSessionState {
  const now = Date.now();
  const expiresAt = now + durationMinutes * 60 * 1000;
  const hours = Math.floor(durationMinutes / 60);
  const mins = durationMinutes % 60;
  const durationLabel = hours > 0 && mins > 0 ? `${hours}h ${mins}m` : hours > 0 ? `${hours} Hours` : `${mins} Minutes`;

  const newState: FocusSessionState = {
    isActive: true,
    mode: 'manual',
    name: `Manual Focus (${durationLabel})`,
    startedAt: now,
    expiresAt,
    blockedApps,
  };
  saveFocusState(newState);
  return newState;
}

// Emergency Access 60s Request
// Rule: Max ONE allowance per rolling 60 minutes
export function requestEmergencyAccess(state: FocusSessionState): { success: boolean; message: string; updatedState: FocusSessionState } {
  const now = Date.now();
  const ONE_HOUR_MS = 60 * 60 * 1000;

  if (state.lastEmergencyAccessTimestamp && (now - state.lastEmergencyAccessTimestamp) < ONE_HOUR_MS) {
    const minutesLeft = Math.ceil((ONE_HOUR_MS - (now - state.lastEmergencyAccessTimestamp)) / (60 * 1000));
    return {
      success: false,
      message: `Emergency access allowance limit reached (1 per hour). Next available in ${minutesLeft} minute${minutesLeft > 1 ? 's' : ''}.`,
      updatedState: state,
    };
  }

  // Grant 60 seconds
  const updatedState: FocusSessionState = {
    ...state,
    lastEmergencyAccessTimestamp: now,
    emergencyAccessExpiresAt: now + 60 * 1000,
  };
  saveFocusState(updatedState);

  return {
    success: true,
    message: 'Granted 60 seconds emergency access. Focus session remains active.',
    updatedState,
  };
}

// App Time Check helpers
export function loadAppTimeCheckConfig(): AppTimeCheckConfig {
  try {
    const raw = localStorage.getItem(APP_TIME_CHECK_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to load app time check config', e);
  }
  const def: AppTimeCheckConfig = {
    enabledApps: DEFAULT_TIME_CHECK_APPS,
    activeSessions: {},
  };
  saveAppTimeCheckConfig(def);
  return def;
}

export function saveAppTimeCheckConfig(config: AppTimeCheckConfig): void {
  try {
    localStorage.setItem(APP_TIME_CHECK_KEY, JSON.stringify(config));
  } catch (e) {
    console.error('Failed to save app time check config', e);
  }
}

// Set app time limit (Strictly 5, 15, or 30 minutes)
export function setAppTimeLimit(appName: string, minutes: 5 | 15 | 30): void {
  const config = loadAppTimeCheckConfig();
  const expiresAt = Date.now() + minutes * 60 * 1000;
  config.activeSessions[appName] = {
    appName,
    durationMinutes: minutes,
    expiresAt,
  };
  saveAppTimeCheckConfig(config);
}
