export type GoalStatus = 'doing' | 'excuse' | 'pending';

export interface GoalItem {
  id: string;
  slotIndex: number; // 0 to 5 (exactly 6 goals)
  title: string;
  status: GoalStatus;
  completedAt?: string; // ISO time string
  excuseReason?: string;
  notes?: string;
}

export interface DailySession {
  date: string; // YYYY-MM-DD
  goals: GoalItem[]; // exactly 6
  isClosed: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface FocusSchedule {
  id: string;
  name: string;
  startTime: string; // HH:mm
  endTime: string;   // HH:mm
  blockedApps: string[];
  isEnabled: boolean;
}

export interface FocusSessionState {
  isActive: boolean;
  mode: 'schedule' | 'manual' | 'none';
  scheduleId?: string;
  name?: string;
  startedAt?: number;
  expiresAt?: number;
  blockedApps: string[];
  lastEmergencyAccessTimestamp?: number; // timestamp of when 60s emergency was used
  emergencyAccessExpiresAt?: number;     // active 60s countdown
}

export interface AppTimeCheckConfig {
  enabledApps: string[];
  activeSessions: Record<string, { appName: string; durationMinutes: number; expiresAt: number }>;
}

export interface UsageStatItem {
  packageName: string;
  appName: string;
  usageMinutesToday: number;
  usageMinutesWeek: number;
  lastTimeUsed: string;
}

export interface ThemeConfig {
  id: string;
  name: string;
  category: 'Galaxies' | 'Forests' | 'Mountains' | 'Lakes' | 'Moonlight & Rain' | 'Anime Scenery' | 'Soft Gradients';
  bgGradient: string;
  cardBg: string;
  textColor: string;
  secondaryTextColor: string;
  accentColor: string;
  isDark: boolean;
  blurLevel: string;
  description: string;
}

export interface FontConfig {
  id: string;
  name: string;
  cssFamily: string;
  category: 'Sans-Serif' | 'Serif' | 'Monospace' | 'Display' | 'Handwritten';
  sampleText: string;
}

export type ClockStyleId = 'double-line' | 'rounded-deco' | 'bold-rounded' | 'minimal-outline';

export interface ClockDesign {
  id: ClockStyleId;
  name: string;
  description: string;
}

export interface PinAuthConfig {
  salt: string;
  pinHash: string; // SHA-256
  isConfigured: boolean;
  requireEditLock: boolean; // optional extra lock for editing titles
}

export interface HistoryDailyRecord {
  date: string;
  goals: GoalItem[];
  doingCount: number;
  excuseCount: number;
  pendingCount: number;
  doingPercent: number;    // doing / 6 * 100
  excusePercent: number;   // excuse / 6 * 100
  pendingPercent: number;  // pending / 6 * 100
  isProvisional?: boolean; // true if current in-progress day
}

export interface InstalledApp {
  id: string;
  name: string;
  packageName: string;
  category: 'system' | 'social' | 'education' | 'tool' | 'entertainment';
  isFavorite: boolean;
  isDock: boolean;
}
