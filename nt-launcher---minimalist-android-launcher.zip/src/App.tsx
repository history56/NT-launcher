import React, { useState, useEffect } from 'react';
import {
  Settings,
  History,
  Shield,
  Layers,
  LayoutGrid,
  Sparkles,
  Smartphone,
  Code,
  CheckCircle2,
  Maximize2,
  Minimize2,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  Wifi,
  Battery,
} from 'lucide-react';
import { GoalItem, GoalStatus, ThemeConfig, FontConfig, ClockStyleId, FocusSessionState } from './types/launcher';
import { THEMES_LIST, FONTS_LIST, CLOCK_DESIGNS } from './utils/themesAndFonts';
import {
  loadOrReconcileCurrentSession,
  saveCurrentSession,
  getLocalDateString,
} from './utils/storage';
import { loadFocusState, evaluateFocusStatus, loadFocusSchedules } from './utils/focusManager';
import { GoalCardsSection } from './components/GoalCardsSection';
import { ClockAndInsightsSection } from './components/ClockAndInsightsSection';
import { FavoritesAndDockSection } from './components/FavoritesAndDockSection';
import { HistoryModal } from './components/HistoryModal';
import { FocusScreen } from './components/FocusScreen';
import { AllAppsScreen } from './components/AllAppsScreen';
import { WidgetsScreen } from './components/WidgetsScreen';
import { SettingsModal } from './components/SettingsModal';
import { FocusBlockOverlayModal } from './components/FocusBlockOverlayModal';
import { AppTimeCheckModal } from './components/AppTimeCheckModal';
import { TestRunnerModal } from './components/TestRunnerModal';
import { AndroidProjectModal } from './components/AndroidProjectModal';

export default function App() {
  // Navigation: 'home' | 'focus' | 'all-apps' | 'widgets'
  const [currentPage, setCurrentPage] = useState<'home' | 'focus' | 'all-apps' | 'widgets'>('home');

  // Customization state
  const [theme, setTheme] = useState<ThemeConfig>(THEMES_LIST[0]);
  const [font, setFont] = useState<FontConfig>(FONTS_LIST[0]);
  const [clockStyle, setClockStyle] = useState<ClockStyleId>('double-line');

  // Active Session & Goals state
  const [session, setSession] = useState(loadOrReconcileCurrentSession());

  // Focus Mode state
  const [focusState, setFocusState] = useState<FocusSessionState>(loadFocusState());

  // Modals state
  const [historyOpen, setHistoryOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [testsOpen, setTestsOpen] = useState(false);
  const [androidStudioHubOpen, setAndroidStudioHubOpen] = useState(false);

  // App Launch Interception state
  const [blockedAppAttempt, setBlockedAppAttempt] = useState<string | null>(null);
  const [timeCheckAppAttempt, setTimeCheckAppAttempt] = useState<string | null>(null);

  // Device frame toggle (Phone Frame vs Immersive Desktop)
  const [isPhoneFrame, setIsPhoneFrame] = useState(true);

  // Status Bar live clock
  const [statusTime, setStatusTime] = useState(
    new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  );

  useEffect(() => {
    const timer = setInterval(() => {
      setStatusTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
      // Periodically evaluate scheduled focus state
      const evaluated = evaluateFocusStatus(loadFocusSchedules());
      setFocusState({ ...evaluated });
    }, 2000);
    return () => clearInterval(timer);
  }, []);

  // Update Goal Title
  const handleUpdateGoalTitle = (goalId: string, newTitle: string) => {
    const updatedGoals = session.goals.map(g => {
      if (g.id === goalId) {
        return { ...g, title: newTitle };
      }
      return g;
    });
    const updatedSession = { ...session, goals: updatedGoals, updatedAt: new Date().toISOString() };
    setSession(updatedSession);
    saveCurrentSession(updatedSession);
  };

  // Update Goal Status
  const handleUpdateGoalStatus = (goalId: string, status: GoalStatus, excuseReason?: string) => {
    const updatedGoals = session.goals.map(g => {
      if (g.id === goalId) {
        return {
          ...g,
          status,
          completedAt: status === 'doing' ? new Date().toISOString() : undefined,
          excuseReason: status === 'excuse' ? excuseReason : undefined,
        };
      }
      return g;
    });
    const updatedSession = { ...session, goals: updatedGoals, updatedAt: new Date().toISOString() };
    setSession(updatedSession);
    saveCurrentSession(updatedSession);
  };

  // Launch App Interceptor
  const handleLaunchApp = (appName: string, packageName: string) => {
    // 1. Check if Focus Mode is Active and this app is blocked
    if (focusState.isActive) {
      const isBlocked =
        focusState.blockedApps.length === 0 ||
        focusState.blockedApps.some(b => b.toLowerCase() === appName.toLowerCase());

      // If active emergency 60s access is unexpired, allow launch
      const hasActiveEmergency =
        focusState.emergencyAccessExpiresAt && Date.now() < focusState.emergencyAccessExpiresAt;

      if (isBlocked && !hasActiveEmergency) {
        setBlockedAppAttempt(appName);
        return;
      }
    }

    // 2. Check if App Time Check is configured for this app (when no focus session)
    const monitoredApps = ['Google', 'Chrome', 'YouTube', 'Instagram', 'Facebook', 'WhatsApp'];
    if (!focusState.isActive && monitoredApps.includes(appName)) {
      setTimeCheckAppAttempt(appName);
      return;
    }

    // Otherwise simulate app launch
    alert(`Launching ${appName} (${packageName}). On Android, NTC Launcher invokes startActivity(intent).`);
  };

  return (
    <div className="w-screen h-screen bg-[#07080c] flex flex-col items-center justify-center overflow-hidden font-sans select-none">
      {/* Top Applet Control Bar */}
      <header className="w-full h-11 bg-black/60 border-b border-white/10 px-4 flex items-center justify-between text-xs text-slate-300 z-30 shrink-0 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 font-semibold text-white tracking-wide">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>NTC Launcher</span>
          </div>
          <span className="text-slate-500 font-mono hidden md:inline">| Native Android 12 Home Launcher</span>
        </div>

        {/* Action Shortcuts */}
        <div className="flex items-center gap-2">
          {/* Quick Page Jump Buttons */}
          <div className="flex bg-white/5 rounded-lg p-0.5 text-[11px] font-medium border border-white/5">
            <button
              onClick={() => setCurrentPage('focus')}
              className={`px-2 py-1 rounded transition-colors ${
                currentPage === 'focus' ? 'bg-indigo-600 text-white font-semibold' : 'text-slate-400 hover:text-white'
              }`}
              title="Swipe Right: Focus Mode"
            >
              Focus (►)
            </button>
            <button
              onClick={() => setCurrentPage('home')}
              className={`px-2 py-1 rounded transition-colors ${
                currentPage === 'home' ? 'bg-indigo-600 text-white font-semibold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Home
            </button>
            <button
              onClick={() => setCurrentPage('all-apps')}
              className={`px-2 py-1 rounded transition-colors ${
                currentPage === 'all-apps' ? 'bg-indigo-600 text-white font-semibold' : 'text-slate-400 hover:text-white'
              }`}
              title="Swipe Left: All Apps"
            >
              All Apps (◄)
            </button>
            <button
              onClick={() => setCurrentPage('widgets')}
              className={`px-2 py-1 rounded transition-colors ${
                currentPage === 'widgets' ? 'bg-indigo-600 text-white font-semibold' : 'text-slate-400 hover:text-white'
              }`}
              title="Swipe Up: Widgets"
            >
              Widgets (▲)
            </button>
          </div>

          <button
            onClick={() => setTestsOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 text-emerald-300 font-medium text-[11px] transition-colors"
            title="Verify 20-Point Requirement Tests"
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">20 Tests</span>
          </button>

          <button
            onClick={() => setAndroidStudioHubOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-indigo-500/15 hover:bg-indigo-500/25 border border-indigo-500/30 text-indigo-300 font-medium text-[11px] transition-colors"
            title="Android Studio Source Code & Vivo V21 Guide"
          >
            <Code className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Android Code</span>
          </button>

          <button
            onClick={() => setSettingsOpen(true)}
            className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-colors"
            title="Launcher Settings"
          >
            <Settings className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => setIsPhoneFrame(!isPhoneFrame)}
            className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
            title={isPhoneFrame ? 'Switch to Fullscreen' : 'Switch to Phone View'}
          >
            {isPhoneFrame ? <Maximize2 className="w-3.5 h-3.5" /> : <Minimize2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 w-full flex items-center justify-center p-0 sm:p-4 overflow-hidden relative">
        {/* Phone Frame or Fullscreen Wrapper */}
        <div
          className={`relative transition-all duration-300 overflow-hidden flex flex-col ${
            isPhoneFrame
              ? 'w-full max-w-[420px] h-[96%] max-h-[860px] rounded-[42px] border-[10px] border-[#1e2029] shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)] ring-1 ring-white/10'
              : 'w-full h-full rounded-none border-none'
          } ${theme.bgGradient}`}
          style={{ fontFamily: font.cssFamily }}
        >
          {/* Subtle Phone Notch / Speaker Bar */}
          {isPhoneFrame && (
            <div className="absolute top-2 left-1/2 -translate-x-1/2 w-28 h-4 bg-black/80 rounded-full z-40 flex items-center justify-center pointer-events-none">
              <div className="w-10 h-1 rounded-full bg-white/20" />
            </div>
          )}

          {/* Android Status Bar */}
          <div className="w-full h-8 px-6 pt-1 flex items-center justify-between text-[11px] font-mono text-slate-400 z-30 shrink-0 pointer-events-none">
            <span className="font-semibold text-slate-200">{statusTime}</span>
            <div className="flex items-center gap-2">
              <Wifi className="w-3 h-3 text-slate-300" />
              <div className="flex items-center gap-1">
                <span>88%</span>
                <Battery className="w-3.5 h-3.5 text-slate-300" />
              </div>
            </div>
          </div>

          {/* Page Routing / Screen Render */}
          <div className="flex-1 w-full flex flex-col px-4 pb-4 overflow-y-auto relative">
            {/* 1. HOME SCREEN */}
            {currentPage === 'home' && (
              <div className="w-full h-full flex flex-col justify-between animate-in fade-in duration-200">
                {/* Fixed Top 6 Goal Cards in 2x3 Layout (No date/weekday above cards; History button only) */}
                <GoalCardsSection
                  goals={session.goals}
                  onUpdateGoalTitle={handleUpdateGoalTitle}
                  onUpdateGoalStatus={handleUpdateGoalStatus}
                  onOpenHistory={() => setHistoryOpen(true)}
                  fontFamily={font.cssFamily}
                />

                {/* Central Adaptive Clock & Real Usage Insights Section */}
                <ClockAndInsightsSection
                  clockStyle={clockStyle}
                  clockFontFamily={font.cssFamily}
                  insightsFontFamily={font.cssFamily}
                />

                {/* Lower-left Favorites & Bottom Dock: Phone, Camera, Khan Global Studies */}
                <FavoritesAndDockSection
                  onLaunchApp={handleLaunchApp}
                  fontFamily={font.cssFamily}
                  onOpenSettings={() => setSettingsOpen(true)}
                />
              </div>
            )}

            {/* 2. FOCUS SCREEN (Swipe Right) */}
            {currentPage === 'focus' && (
              <FocusScreen
                onBackToHome={() => setCurrentPage('home')}
                onSimulateAppLaunch={(appName) => setBlockedAppAttempt(appName)}
              />
            )}

            {/* 3. ALL APPS SCREEN (Swipe Left) */}
            {currentPage === 'all-apps' && (
              <AllAppsScreen
                onBackToHome={() => setCurrentPage('home')}
                onLaunchApp={handleLaunchApp}
                fontFamily={font.cssFamily}
              />
            )}

            {/* 4. WIDGETS SCREEN (Swipe Up) */}
            {currentPage === 'widgets' && (
              <WidgetsScreen
                onBackToHome={() => setCurrentPage('home')}
              />
            )}
          </div>

          {/* Android Gesture Navigation Bar at Bottom */}
          <div className="w-full h-5 flex items-center justify-center shrink-0 pb-1 z-30">
            <button
              onClick={() => setCurrentPage('home')}
              className="w-32 h-1 bg-white/30 rounded-full hover:bg-white/60 transition-colors"
              title="Home Gesture Bar"
            />
          </div>
        </div>
      </main>

      {/* POPUP MODALS */}

      {/* 1. History Modal */}
      <HistoryModal
        isOpen={historyOpen}
        onClose={() => setHistoryOpen(false)}
        onHistoryReset={() => {
          setSession(loadOrReconcileCurrentSession());
        }}
      />

      {/* 2. Settings Modal */}
      <SettingsModal
        isOpen={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        currentTheme={theme}
        onSelectTheme={setTheme}
        currentFont={font}
        onSelectFont={setFont}
        currentClockStyle={clockStyle}
        onSelectClockStyle={setClockStyle}
        onOpenHistoryModal={() => setHistoryOpen(true)}
        onOpenTestRunner={() => setTestsOpen(true)}
        onOpenAndroidStudioHub={() => setAndroidStudioHubOpen(true)}
      />

      {/* 3. Focus Block Overlay Modal (When a blocked app is launched) */}
      <FocusBlockOverlayModal
        isOpen={Boolean(blockedAppAttempt)}
        blockedAppName={blockedAppAttempt || ''}
        focusState={focusState}
        onClose={() => setBlockedAppAttempt(null)}
        onEmergencyGranted={(updated) => {
          setFocusState({ ...updated });
          setBlockedAppAttempt(null);
        }}
      />

      {/* 4. App Time Check Modal (5, 15, or 30 minutes) */}
      <AppTimeCheckModal
        isOpen={Boolean(timeCheckAppAttempt)}
        appName={timeCheckAppAttempt || ''}
        onSelectDuration={(duration) => {
          alert(`Granted ${duration} minutes usage for ${timeCheckAppAttempt}. NTC Launcher will monitor session expiration.`);
          setTimeCheckAppAttempt(null);
        }}
        onCancel={() => setTimeCheckAppAttempt(null)}
      />

      {/* 5. 20-Point Requirement Test Suite */}
      <TestRunnerModal
        isOpen={testsOpen}
        onClose={() => setTestsOpen(false)}
        onSimulateMidnightRollover={() => {
          setSession(loadOrReconcileCurrentSession());
        }}
      />

      {/* 6. Native Android Studio Code Explorer */}
      <AndroidProjectModal
        isOpen={androidStudioHubOpen}
        onClose={() => setAndroidStudioHubOpen(false)}
      />
    </div>
  );
}
